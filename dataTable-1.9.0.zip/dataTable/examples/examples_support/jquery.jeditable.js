/*
 * Jeditable - jQuery in place edit plugin
 *
 * Copyright (c) 2006-2009 Mika Tuupola, Dylan Verheul
 *
 * Licensed under the MIT license:
 *   http://www.opensource.org/licenses/mit-license.php
 *
 * Project home:
 *   http://www.appelsiini.net/projects/jeditable
 *
 * Based on editable by Dylan Verheul <dylan_at_dyve.net>:
 *    http://www.dyve.net/jquery/?editable
 *
 */

/**
  * Version 1.7.1
  *
  * ** means there is basic unit tests for this parameter. 
  *
  * @name  Jeditable
  * @type  jQuery
  * @param String  target             (POST) URL or function to send edited content to **
  * @param Hash    options            additional options 
  * @param String  options[method]    method to use to send edited content (POST or PUT) **
  * @param Function options[callback] Function to run after submitting edited content **
  * @param String  options[name]      POST parameter name of edited content
  * @param String  options[id]        POST parameter name of edited div id
  * @param Hash    options[submitdata] Extra parameters to send when submitting edited content.
  * @param String  options[type]      text, textarea or select (or any 3rd party input type) **
  * @param Integer options[rows]      number of rows if using textarea ** 
  * @param Integer options[cols]      number of columns if using textarea **
  * @param Mixed   options[height]    'auto', 'none' or height in pixels **
  * @param Mixed   options[width]     'auto', 'none' or width in pixels **
  * @param String  options[loadurl]   URL to fetch input content before editing **
  * @param String  options[loadtype]  Request type for load url. Should be GET or POST.
  * @param String  options[loadtext]  Text to display while loading external content.
  * @param Mixed   options[loaddata]  Extra parameters to pass when fetching content before editing.
  * @param Mixed   options[data]      Or content given as paramameter. String or function.**
  * @param String  options[indicator] indicator html to show when saving
  * @param String  options[tooltip]   optional tooltip text via title attribute **
  * @param String  options[event]     jQuery event such as 'click' of 'dblclick' **
  * @param String  options[submit]    submit button value, empty means no button **
  * @param String  options[cancel]    cancel button value, empty means no button **
  * @param String  options[cssclass]  CSS class to apply to input form. 'inherit' to copy from parent. **
  * @param String  options[style]     Style to apply to input form 'inherit' to copy from parent. **
  * @param String  options[select]    true or false, when true text is highlighted ??
  * @param String  options[placeholder] Placeholder text or html to insert when element is empty. **
  * @param String  options[onblur]    'cancel', 'submit', 'ignore' or function ??
  *             
  * @param Function options[onsubmit] function(configurations, original) { ... } called before submit
  * @param Function options[onreset]  function(configurations, original) { ... } called before reset
  * @param Function options[onerror]  function(configurations, original, xhr) { ... } called on error
  *             
  * @param Hash    options[ajaxoptions]  jQuery Ajax options. See docs.jquery.com.
  *             
  */

(function($) {

    $.fn.editable = function(target, options) {
            
        if ('disable' == target) {
            $(this).data('disabled.editable', true);
            return;
        }
        if ('enable' == target) {
            $(this).data('disabled.editable', false);
            return;
        }
        if ('destroy' == target) {
            $(this)
                .unbind($(this).data('event.editable'))
                .removeData('disabled.editable')
                .removeData('event.editable');
            return;
        }
        
        var configurations = $.extend({}, $.fn.editable.defaults, {target:target}, options);
        
        /* setup some functions */
        var plugin   = $.editable.types[configurations.type].plugin || function() { };
        var submit   = $.editable.types[configurations.type].submit || function() { };
        var buttons  = $.editable.types[configurations.type].buttons 
                    || $.editable.types['defaults'].buttons;
        var content  = $.editable.types[configurations.type].content 
                    || $.editable.types['defaults'].content;
        var element  = $.editable.types[configurations.type].element 
                    || $.editable.types['defaults'].element;
        var reset    = $.editable.types[configurations.type].reset 
                    || $.editable.types['defaults'].reset;
        var callback = configurations.callback || function() { };
        var onedit   = configurations.onedit   || function() { }; 
        var onsubmit = configurations.onsubmit || function() { };
        var onreset  = configurations.onreset  || function() { };
        var onerror  = configurations.onerror  || reset;
          
        /* show tooltip */
        if (configurations.tooltip) {
            $(this).attr('title', configurations.tooltip);
        }
        
        configurations.autowidth  = 'auto' == configurations.width;
        configurations.autoheight = 'auto' == configurations.height;
        
        return this.each(function() {
                        
            /* save this to self because this changes when scope changes */
            var self = this;  
                   
            /* inlined block elements lose their width and height after first edit */
            /* save them for later use as workaround */
            var savedwidth  = $(self).width();
            var savedheight = $(self).height();
            
            /* save so it can be later used by $.editable('destroy') */
            $(this).data('event.editable', configurations.event);
            
            /* if element is empty add something clickable (if requested) */
            if (!$.trim($(this).html())) {
                $(this).html(configurations.placeholder);
            }
            
            $(this).bind(configurations.event, function(e) {
                
                /* abort if disabled for this element */
                if (true === $(this).data('disabled.editable')) {
                    return;
                }
                
                /* prevent throwing an exeption if edit field is clicked again */
                if (self.editing) {
                    return;
                }
                
                /* abort if onedit hook returns false */
                if (false === onedit.apply(this, [configurations, self])) {
                   return;
                }
                
                /* prevent default action and bubbling */
                e.preventDefault();
                e.stopPropagation();
                
                /* remove tooltip */
                if (configurations.tooltip) {
                    $(self).removeAttr('title');
                }
                
                /* figure out how wide and tall we are, saved width and height */
                /* are workaround for http://dev.jquery.com/ticket/2190 */
                if (0 == $(self).width()) {
                    //$(self).css('visibility', 'hidden');
                    configurations.width  = savedwidth;
                    configurations.height = savedheight;
                } else {
                    if (configurations.width != 'none') {
                        configurations.width = 
                            configurations.autowidth ? $(self).width()  : configurations.width;
                    }
                    if (configurations.height != 'none') {
                        configurations.height = 
                            configurations.autoheight ? $(self).height() : configurations.height;
                    }
                }
                //$(this).css('visibility', '');
                
                /* remove placeholder text, replace is here because of IE */
                if ($(this).html().toLowerCase().replace(/(;|")/g, '') == 
                    configurations.placeholder.toLowerCase().replace(/(;|")/g, '')) {
                        $(this).html('');
                }
                                
                self.editing    = true;
                self.revert     = $(self).html();
                $(self).html('');

                /* create the form object */
                var form = $('<form />');
                
                /* apply css or style or both */
                if (configurations.cssclass) {
                    if ('inherit' == configurations.cssclass) {
                        form.attr('class', $(self).attr('class'));
                    } else {
                        form.attr('class', configurations.cssclass);
                    }
                }

                if (configurations.style) {
                    if ('inherit' == configurations.style) {
                        form.attr('style', $(self).attr('style'));
                        /* IE needs the second line or display wont be inherited */
                        form.css('display', $(self).css('display'));                
                    } else {
                        form.attr('style', configurations.style);
                    }
                }

                /* add main input element to form and store it in input */
                var input = element.apply(form, [configurations, self]);

                /* set input content via POST, GET, given data or existing value */
                var input_content;
                
                if (configurations.loadurl) {
                    var t = setTimeout(function() {
                        input.disabled = true;
                        content.apply(form, [configurations.loadtext, configurations, self]);
                    }, 100);

                    var loaddata = {};
                    loaddata[configurations.id] = self.id;
                    if ($.isFunction(configurations.loaddata)) {
                        $.extend(loaddata, configurations.loaddata.apply(self, [self.revert, configurations]));
                    } else {
                        $.extend(loaddata, configurations.loaddata);
                    }
                    $.ajax({
                       type : configurations.loadtype,
                       url  : configurations.loadurl,
                       data : loaddata,
                       async : false,
                       success: function(result) {
                          window.clearTimeout(t);
                          input_content = result;
                          input.disabled = false;
                       }
                    });
                } else if (configurations.data) {
                    input_content = configurations.data;
                    if ($.isFunction(configurations.data)) {
                        input_content = configurations.data.apply(self, [self.revert, configurations]);
                    }
                } else {
                    input_content = self.revert; 
                }
                content.apply(form, [input_content, configurations, self]);

                input.attr('name', configurations.name);
        
                /* add buttons to the form */
                buttons.apply(form, [configurations, self]);
         
                /* add created form to self */
                $(self).append(form);
         
                /* attach 3rd party plugin if requested */
                plugin.apply(form, [configurations, self]);

                /* focus to first visible form element */
                $(':input:visible:enabled:first', form).focus();

                /* highlight input contents when requested */
                if (configurations.select) {
                    input.select();
                }
        
                /* discard changes if pressing esc */
                input.keydown(function(e) {
                    if (e.keyCode == 27) {
                        e.preventDefault();
                        //self.reset();
                        reset.apply(form, [configurations, self]);
                    }
                });

                /* discard, submit or nothing with changes when clicking outside */
                /* do nothing is usable when navigating with tab */
                var t;
                if ('cancel' == configurations.onblur) {
                    input.blur(function(e) {
                        /* prevent canceling if submit was clicked */
                        t = setTimeout(function() {
                            reset.apply(form, [configurations, self]);
                        }, 500);
                    });
                } else if ('submit' == configurations.onblur) {
                    input.blur(function(e) {
                        /* prevent double submit if submit was clicked */
                        t = setTimeout(function() {
                            form.submit();
                        }, 200);
                    });
                } else if ($.isFunction(configurations.onblur)) {
                    input.blur(function(e) {
                        configurations.onblur.apply(self, [input.val(), configurations]);
                    });
                } else {
                    input.blur(function(e) {
                      /* TODO: maybe something here */
                    });
                }

                form.submit(function(e) {

                    if (t) { 
                        clearTimeout(t);
                    }

                    /* do no submit */
                    e.preventDefault(); 
            
                    /* call before submit hook. */
                    /* if it returns false abort submitting */                    
                    if (false !== onsubmit.apply(form, [configurations, self])) { 
                        /* custom inputs call before submit hook. */
                        /* if it returns false abort submitting */
                        if (false !== submit.apply(form, [configurations, self])) { 

                          /* check if given target is function */
                          if ($.isFunction(configurations.target)) {
                              var str = configurations.target.apply(self, [input.val(), configurations]);
                              $(self).html(str);
                              self.editing = false;
                              callback.apply(self, [self.innerHTML, configurations]);
                              /* TODO: this is not dry */                              
                              if (!$.trim($(self).html())) {
                                  $(self).html(configurations.placeholder);
                              }
                          } else {
                              /* add edited content and id of edited element to POST */
                              var submitdata = {};
                              submitdata[configurations.name] = input.val();
                              submitdata[configurations.id] = self.id;
                              /* add extra data to be POST:ed */
                              if ($.isFunction(configurations.submitdata)) {
                                  $.extend(submitdata, configurations.submitdata.apply(self, [self.revert, configurations]));
                              } else {
                                  $.extend(submitdata, configurations.submitdata);
                              }

                              /* quick and dirty PUT support */
                              if ('PUT' == configurations.method) {
                                  submitdata['_method'] = 'put';
                              }

                              /* show the saving indicator */
                              $(self).html(configurations.indicator);
                              
                              /* defaults for ajaxoptions */
                              var ajaxoptions = {
                                  type    : 'POST',
                                  data    : submitdata,
                                  dataType: 'html',
                                  url     : configurations.target,
                                  success : function(result, status) {
                                      if (ajaxoptions.dataType == 'html') {
                                        $(self).html(result);
                                      }
                                      self.editing = false;
                                      callback.apply(self, [result, configurations]);
                                      if (!$.trim($(self).html())) {
                                          $(self).html(configurations.placeholder);
                                      }
                                  },
                                  error   : function(xhr, status, error) {
                                      onerror.apply(form, [configurations, self, xhr]);
                                  }
                              };
                              
                              /* override with what is given in configurations.ajaxoptions */
                              $.extend(ajaxoptions, configurations.ajaxoptions);   
                              $.ajax(ajaxoptions);          
                              
                            }
                        }
                    }
                    
                    /* show tooltip again */
                    $(self).attr('title', configurations.tooltip);
                    
                    return false;
                });
            });
            
            /* privileged methods */
            this.reset = function(form) {
                /* prevent calling reset twice when blurring */
                if (this.editing) {
                    /* before reset hook, if it returns false abort reseting */
                    if (false !== onreset.apply(form, [configurations, self])) { 
                        $(self).html(self.revert);
                        self.editing   = false;
                        if (!$.trim($(self).html())) {
                            $(self).html(configurations.placeholder);
                        }
                        /* show tooltip again */
                        if (configurations.tooltip) {
                            $(self).attr('title', configurations.tooltip);                
                        }
                    }                    
                }
            };            
        });

    };


    $.editable = {
        types: {
            defaults: {
                element : function(configurations, original) {
                    var input = $('<input type="hidden"></input>');                
                    $(this).append(input);
                    return(input);
                },
                content : function(string, configurations, original) {
                    $(':input:first', this).val(string);
                },
                reset : function(configurations, original) {
                  original.reset(this);
                },
                buttons : function(configurations, original) {
                    var form = this;
                    if (configurations.submit) {
                        /* if given html string use that */
                        if (configurations.submit.match(/>$/)) {
                            var submit = $(configurations.submit).click(function() {
                                if (submit.attr("type") != "submit") {
                                    form.submit();
                                }
                            });
                        /* otherwise use button with given string as text */
                        } else {
                            var submit = $('<button type="submit" />');
                            submit.html(configurations.submit);                            
                        }
                        $(this).append(submit);
                    }
                    if (configurations.cancel) {
                        /* if given html string use that */
                        if (configurations.cancel.match(/>$/)) {
                            var cancel = $(configurations.cancel);
                        /* otherwise use button with given string as text */
                        } else {
                            var cancel = $('<button type="cancel" />');
                            cancel.html(configurations.cancel);
                        }
                        $(this).append(cancel);

                        $(cancel).click(function(event) {
                            //original.reset();
                            if ($.isFunction($.editable.types[configurations.type].reset)) {
                                var reset = $.editable.types[configurations.type].reset;                                                                
                            } else {
                                var reset = $.editable.types['defaults'].reset;                                
                            }
                            reset.apply(form, [configurations, original]);
                            return false;
                        });
                    }
                }
            },
            text: {
                element : function(configurations, original) {
                    var input = $('<input />');
                    if (configurations.width  != 'none') { input.width(configurations.width);  }
                    if (configurations.height != 'none') { input.height(configurations.height); }
                    /* https://bugzilla.mozilla.org/show_bug.cgi?id=236791 */
                    //input[0].setAttribute('autocomplete','off');
                    input.attr('autocomplete','off');
                    $(this).append(input);
                    return(input);
                }
            },
            textarea: {
                element : function(configurations, original) {
                    var textarea = $('<textarea />');
                    if (configurations.rows) {
                        textarea.attr('rows', configurations.rows);
                    } else if (configurations.height != "none") {
                        textarea.height(configurations.height);
                    }
                    if (configurations.cols) {
                        textarea.attr('cols', configurations.cols);
                    } else if (configurations.width != "none") {
                        textarea.width(configurations.width);
                    }
                    $(this).append(textarea);
                    return(textarea);
                }
            },
            select: {
               element : function(configurations, original) {
                    var select = $('<select />');
                    $(this).append(select);
                    return(select);
                },
                content : function(data, configurations, original) {
                    /* If it is string assume it is json. */
                    if (String == data.constructor) {      
                        eval ('var json = ' + data);
                    } else {
                    /* Otherwise assume it is a hash already. */
                        var json = data;
                    }
                    for (var key in json) {
                        if (!json.hasOwnProperty(key)) {
                            continue;
                        }
                        if ('selected' == key) {
                            continue;
                        } 
                        var option = $('<option />').val(key).append(json[key]);
                        $('select', this).append(option);    
                    }                    
                    /* Loop option again to set selected. IE needed this... */ 
                    $('select', this).children().each(function() {
                        if ($(this).val() == json['selected'] || 
                            $(this).text() == $.trim(original.revert)) {
                                $(this).attr('selected', 'selected');
                        }
                    });
                }
            }
        },

        /* Add new input type */
        addInputType: function(name, input) {
            $.editable.types[name] = input;
        }
    };

    // publicly accessible defaults
    $.fn.editable.defaults = {
        name       : 'value',
        id         : 'id',
        type       : 'text',
        width      : 'auto',
        height     : 'auto',
        event      : 'click.editable',
        onblur     : 'cancel',
        loadtype   : 'GET',
        loadtext   : 'Loading...',
        placeholder: 'Click to edit',
        loaddata   : {},
        submitdata : {},
        ajaxoptions: {}
    };

})(jQuery);