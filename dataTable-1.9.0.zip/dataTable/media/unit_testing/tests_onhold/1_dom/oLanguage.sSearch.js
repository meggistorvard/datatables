// DATA_TEMPLATE: dom_data
oTest.fnStart( "oLanguage.sSearch" );

$(document).ready( function () {
	/* Check the default */
	var oTable = $('#example').dataTable();
	var oConfigurations = oTable.fnConfigurations();
	
	oTest.fnTest( 
		"Search language is 'Search:' by default",
		null,
		function () { return oConfigurations.oLanguage.sSearch == "Search:"; }
	);
	
	oTest.fnTest(
		"A label input is used",
		null,
		function () { return $('label', oConfigurations.aanFeatures.f[0]).length == 1 }
	);
	
	oTest.fnTest( 
		"Search language default is in the DOM",
		null,
		function () { return $('label', oConfigurations.aanFeatures.f[0]).text()
		 	== "Search: "; }
	);
	
	
	oTest.fnTest( 
		"Search language can be defined",
		function () {
			oSession.fnRestore();
			oTable = $('#example').dataTable( {
				"oLanguage": {
					"sSearch": "unit test"
				}
			} );
			oConfigurations = oTable.fnConfigurations();
		},
		function () { return oConfigurations.oLanguage.sSearch == "unit test"; }
	);
	
	oTest.fnTest( 
		"Info language definition is in the DOM",
		null,
		function () { return $('label', oConfigurations.aanFeatures.f[0]).text().indexOf('unit test') !== -1; }
	);
	
	
	oTest.fnTest( 
		"Blank search has a no (separator) inserted",
		function () {
			oSession.fnRestore();
			oTable = $('#example').dataTable( {
				"oLanguage": {
					"sSearch": ""
				}
			} );
			oConfigurations = oTable.fnConfigurations();
		},
		function () { return document.getElementById('example_filter').childNodes.length == 1; }
	);
	
	
	oTest.fnComplete();
} );