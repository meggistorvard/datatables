// DATA_TEMPLATE: dom_data
oTest.fnStart( "oLanguage.sUrl" );

/* Note that we only test the internal storage of language information pulled form a file here
 * as the other language tests will check it goes into the DOM correctly
 */

$(document).ready( function () {
	/* Check the default */
	var oTable = $('#example').dataTable();
	var oConfigurations = oTable.fnConfigurations();
	
	oTest.fnTest( 
		"sUrl is blank by default",
		null,
		function () { return oConfigurations.oLanguage.sUrl == ""; }
	);
	
	
	oTest.fnWaitTest( 
		"Loading of German file loads language information",
		function () {
			oSession.fnRestore();
			oTable = $('#example').dataTable( {
				"oLanguage": {
					"sUrl": "../../../examples/examples_support/de_DE.txt"
				}
			} );
			oConfigurations = oTable.fnConfigurations();
		},
		function () {
			var bReturn = 
				oConfigurations.oLanguage.sProcessing == "Bitte warten..." &&
				oConfigurations.oLanguage.sLengthMenu == "_MENU_ Einträge anzeigen" &&
				oConfigurations.oLanguage.sZeroRecords == "Keine Einträge vorhanden." &&
				oConfigurations.oLanguage.sInfo == "_START_ bis _END_ von _TOTAL_ Einträgen" &&
				oConfigurations.oLanguage.sInfoEmpty == "0 bis 0 von 0 Einträgen" &&
				oConfigurations.oLanguage.sInfoFiltered == "(gefiltert von _MAX_  Einträgen)" &&
				oConfigurations.oLanguage.sInfoPostFix == "" &&
				oConfigurations.oLanguage.sSearch == "Suchen" &&
				oConfigurations.oLanguage.oPaginate.sFirst == "Erster" &&
				oConfigurations.oLanguage.oPaginate.sPrevious == "Zurück" &&
				oConfigurations.oLanguage.oPaginate.sNext == "Nächster" &&
				oConfigurations.oLanguage.oPaginate.sLast == "Letzter";
				
			return bReturn;
		}
	);
	
	/* One DOM check just to ensure that they go into the DOM */
	oTest.fnTest(
		"Loaded language goes into the DOM",
		null,
		function () { return document.getElementById('example_info').innerHTML = "1 bis 10 von 57 Einträgen"; }
	);
	
	
	oTest.fnComplete();
} );