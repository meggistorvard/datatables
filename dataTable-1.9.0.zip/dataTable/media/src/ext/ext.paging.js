
/*
 * Variable: oPagination
 * Purpose:  
 * Scope:    jQuery.fn.dataTableExt
 */
$.extend( DataTable.ext.oPagination, {
	/*
	 * Variable: two_button
	 * Purpose:  Standard two button (forward/back) pagination
	 * Scope:    jQuery.fn.dataTableExt.oPagination
	 */
	"two_button": {
		/*
		 * Function: oPagination.two_button.fnInit
		 * Purpose:  Initialise dom elements required for pagination with forward/back buttons only
		 * Returns:  -
		 * Inputs:   object:oConfigurations - dataTables configurations object
		 *           node:nPaging - the DIV which contains this pagination control
		 *           function:fnCallbackDraw - draw function which must be called on update
		 */
		"fnInit": function ( oConfigurations, nPaging, fnCallbackDraw )
		{
			var oLang = oConfigurations.oLanguage.oPaginate;
			var oClasses = oConfigurations.oClasses;
			var fnClickHandler = function ( e ) {
				if ( oConfigurations.oApi._fnPageChange( oConfigurations, e.data.action ) )
				{
					fnCallbackDraw( oConfigurations );
				}
			};

			var sAppend = (!oConfigurations.bJUI) ?
				'<a class="'+oConfigurations.oClasses.sPagePrevDisabled+'" tabindex="'+oConfigurations.iTabIndex+'" role="button">'+oLang.sPrevious+'</a>'+
				'<a class="'+oConfigurations.oClasses.sPageNextDisabled+'" tabindex="'+oConfigurations.iTabIndex+'" role="button">'+oLang.sNext+'</a>'
				:
				'<a class="'+oConfigurations.oClasses.sPagePrevDisabled+'" tabindex="'+oConfigurations.iTabIndex+'" role="button"><span class="'+oConfigurations.oClasses.sPageJUIPrev+'"></span></a>'+
				'<a class="'+oConfigurations.oClasses.sPageNextDisabled+'" tabindex="'+oConfigurations.iTabIndex+'" role="button"><span class="'+oConfigurations.oClasses.sPageJUINext+'"></span></a>';
			$(nPaging).append( sAppend );
			
			var els = $('a', nPaging);
			var nPrevious = els[0],
				nNext = els[1];
			
			oConfigurations.oApi._fnBindAction( nPrevious, {action: "previous"}, fnClickHandler );
			oConfigurations.oApi._fnBindAction( nNext,     {action: "next"},     fnClickHandler );
			
			/* ID the first elements only */
			if ( !oConfigurations.aanFeatures.p )
			{
				nPaging.id = oConfigurations.sTableId+'_paginate';
				nPrevious.id = oConfigurations.sTableId+'_previous';
				nNext.id = oConfigurations.sTableId+'_next';

				nPrevious.setAttribute('aria-controls', oConfigurations.sTableId);
				nNext.setAttribute('aria-controls', oConfigurations.sTableId);
			}
		},
		
		/*
		 * Function: oPagination.two_button.fnUpdate
		 * Purpose:  Update the two button pagination at the end of the draw
		 * Returns:  -
		 * Inputs:   object:oConfigurations - dataTables configurations object
		 *           function:fnCallbackDraw - draw function to call on page change
		 */
		"fnUpdate": function ( oConfigurations, fnCallbackDraw )
		{
			if ( !oConfigurations.aanFeatures.p )
			{
				return;
			}
			
			var oClasses = oConfigurations.oClasses;
			var an = oConfigurations.aanFeatures.p;

			/* Loop over each instance of the pager */
			for ( var i=0, iLen=an.length ; i<iLen ; i++ )
			{
				if ( an[i].childNodes.length !== 0 )
				{
					an[i].childNodes[0].className = ( oConfigurations._iDisplayStart === 0 ) ? 
						oClasses.sPagePrevDisabled : oClasses.sPagePrevEnabled;
					
					an[i].childNodes[1].className = ( oConfigurations.fnDisplayEnd() == oConfigurations.fnRecordsDisplay() ) ? 
						oClasses.sPageNextDisabled : oClasses.sPageNextEnabled;
				}
			}
		}
	},
	
	
	/*
	 * Variable: iFullNumbersShowPages
	 * Purpose:  Change the number of pages which can be seen
	 * Scope:    jQuery.fn.dataTableExt.oPagination
	 */
	"iFullNumbersShowPages": 5,
	
	/*
	 * Variable: full_numbers
	 * Purpose:  Full numbers pagination
	 * Scope:    jQuery.fn.dataTableExt.oPagination
	 */
	"full_numbers": {
		/*
		 * Function: oPagination.full_numbers.fnInit
		 * Purpose:  Initialise dom elements required for pagination with a list of the pages
		 * Returns:  -
		 * Inputs:   object:oConfigurations - dataTables configurations object
		 *           node:nPaging - the DIV which contains this pagination control
		 *           function:fnCallbackDraw - draw function which must be called on update
		 */
		"fnInit": function ( oConfigurations, nPaging, fnCallbackDraw )
		{
			var oLang = oConfigurations.oLanguage.oPaginate;
			var oClasses = oConfigurations.oClasses;
			var fnClickHandler = function ( e ) {
				if ( oConfigurations.oApi._fnPageChange( oConfigurations, e.data.action ) )
				{
					fnCallbackDraw( oConfigurations );
				}
			};

			$(nPaging).append(
				'<a  tabindex="'+oConfigurations.iTabIndex+'" class="'+oClasses.sPageButton+" "+oClasses.sPageFirst+'">'+oLang.sFirst+'</a>'+
				'<a  tabindex="'+oConfigurations.iTabIndex+'" class="'+oClasses.sPageButton+" "+oClasses.sPagePrevious+'">'+oLang.sPrevious+'</a>'+
				'<span></span>'+
				'<a tabindex="'+oConfigurations.iTabIndex+'" class="'+oClasses.sPageButton+" "+oClasses.sPageNext+'">'+oLang.sNext+'</a>'+
				'<a tabindex="'+oConfigurations.iTabIndex+'" class="'+oClasses.sPageButton+" "+oClasses.sPageLast+'">'+oLang.sLast+'</a>'
			);
			var els = $('a', nPaging);
			var nFirst = els[0],
				nPrev = els[1],
				nNext = els[2],
				nLast = els[3];
			
			oConfigurations.oApi._fnBindAction( nFirst, {action: "first"},    fnClickHandler );
			oConfigurations.oApi._fnBindAction( nPrev,  {action: "previous"}, fnClickHandler );
			oConfigurations.oApi._fnBindAction( nNext,  {action: "next"},     fnClickHandler );
			oConfigurations.oApi._fnBindAction( nLast,  {action: "last"},     fnClickHandler );
			
			/* ID the first elements only */
			if ( !oConfigurations.aanFeatures.p )
			{
				nPaging.id = oConfigurations.sTableId+'_paginate';
				nFirst.id =oConfigurations.sTableId+'_first';
				nPrev.id =oConfigurations.sTableId+'_previous';
				nNext.id =oConfigurations.sTableId+'_next';
				nLast.id =oConfigurations.sTableId+'_last';
			}
		},
		
		/*
		 * Function: oPagination.full_numbers.fnUpdate
		 * Purpose:  Update the list of page buttons shows
		 * Returns:  -
		 * Inputs:   object:oConfigurations - dataTables configurations object
		 *           function:fnCallbackDraw - draw function to call on page change
		 */
		"fnUpdate": function ( oConfigurations, fnCallbackDraw )
		{
			if ( !oConfigurations.aanFeatures.p )
			{
				return;
			}
			
			var iPageCount = DataTable.ext.oPagination.iFullNumbersShowPages;
			var iPageCountHalf = Math.floor(iPageCount / 2);
			var iPages = Math.ceil((oConfigurations.fnRecordsDisplay()) / oConfigurations._iDisplayLength);
			var iCurrentPage = Math.ceil(oConfigurations._iDisplayStart / oConfigurations._iDisplayLength) + 1;
			var sList = "";
			var iStartButton, iEndButton, i, iLen;
			var oClasses = oConfigurations.oClasses;
			var anButtons, anStatic, nPaginateList;
			var an = oConfigurations.aanFeatures.p;
			var fnBind = function (j) {
				oConfigurations.oApi._fnBindAction( this, {"page": j+iStartButton-1}, function(e) {
					/* Use the information in the element to jump to the required page */
					oConfigurations.oApi._fnPageChange( oConfigurations, e.data.page );
					fnCallbackDraw( oConfigurations );
					e.preventDefault();
				} );
			};
			
			/* Pages calculation */
			if (iPages < iPageCount)
			{
				iStartButton = 1;
				iEndButton = iPages;
			}
			else if (iCurrentPage <= iPageCountHalf)
			{
				iStartButton = 1;
				iEndButton = iPageCount;
			}
			else if (iCurrentPage >= (iPages - iPageCountHalf))
			{
				iStartButton = iPages - iPageCount + 1;
				iEndButton = iPages;
			}
			else
			{
				iStartButton = iCurrentPage - Math.ceil(iPageCount / 2) + 1;
				iEndButton = iStartButton + iPageCount - 1;
			}
			
			/* Build the dynamic list */
			for ( i=iStartButton ; i<=iEndButton ; i++ )
			{
				sList += (iCurrentPage !== i) ?
					'<a tabindex="'+oConfigurations.iTabIndex+'" class="'+oClasses.sPageButton+'">'+oConfigurations.fnFormatNumber(i)+'</a>' :
					'<a tabindex="'+oConfigurations.iTabIndex+'" class="'+oClasses.sPageButtonActive+'">'+oConfigurations.fnFormatNumber(i)+'</a>';
			}
			
			/* Loop over each instance of the pager */
			for ( i=0, iLen=an.length ; i<iLen ; i++ )
			{
				if ( an[i].childNodes.length === 0 )
				{
					continue;
				}
				
				/* Build up the dynamic list forst - html and listeners */
				$('span:eq(0)', an[i])
					.html( sList )
					.children('a').each( fnBind );
				
				/* Update the premanent botton's classes */
				anButtons = an[i].getElementsByTagName('a');
				anStatic = [
					anButtons[0], anButtons[1], 
					anButtons[anButtons.length-2], anButtons[anButtons.length-1]
				];

				$(anStatic).removeClass( oClasses.sPageButton+" "+oClasses.sPageButtonActive+" "+oClasses.sPageButtonStaticDisabled );
				$([anStatic[0], anStatic[1]]).addClass( 
					(iCurrentPage==1) ?
						oClasses.sPageButtonStaticDisabled :
						oClasses.sPageButton
				);
				$([anStatic[2], anStatic[3]]).addClass(
					(iPages===0 || iCurrentPage===iPages || oConfigurations._iDisplayLength===-1) ?
						oClasses.sPageButtonStaticDisabled :
						oClasses.sPageButton
				);
			}
		}
	}
} );
