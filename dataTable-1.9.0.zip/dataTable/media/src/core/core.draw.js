

/**
 * Create a new TR element (and it's TD children) for a row
 *  @param {object} oConfigurations dataTables configurations object
 *  @param {int} iRow Row to consider
 *  @memberof DataTable#oApi
 */
function _fnCreateTr ( oConfigurations, iRow )
{
	var oData = oConfigurations.aoData[iRow];
	var nTd;

	if ( oData.nTr === null )
	{
		oData.nTr = document.createElement('tr');

		/* Use a private property on the node to allow reserve mapping from the node
		 * to the aoData array for fast look up
		 */
		oData.nTr._DT_RowIndex = iRow;

		/* Special parameters can be given by the data source to be used on the row */
		if ( oData._aData.DT_RowId )
		{
			oData.nTr.id = oData._aData.DT_RowId;
		}

		if ( oData._aData.DT_RowClass )
		{
			$(oData.nTr).addClass( oData._aData.DT_RowClass );
		}

		/* Process each column */
		for ( var i=0, iLen=oConfigurations.aoColumns.length ; i<iLen ; i++ )
		{
			var oCol = oConfigurations.aoColumns[i];
			nTd = document.createElement('td');

			/* Render if needed - if bUseRendered is true then we already have the rendered
			 * value in the data source - so can just use that
			 */
			nTd.innerHTML = (typeof oCol.fnRender === 'function' && (!oCol.bUseRendered || oCol.mDataProp === null)) ?
				_fnRender( oConfigurations, iRow, i ) :
				_fnGetCellData( oConfigurations, iRow, i, 'display' );
		
			/* Add member defined class */
			if ( oCol.sClass !== null )
			{
				nTd.className = oCol.sClass;
			}
			
			if ( oCol.bVisible )
			{
				oData.nTr.appendChild( nTd );
				oData._anHidden[i] = null;
			}
			else
			{
				oData._anHidden[i] = nTd;
			}

			if ( oCol.fnCreatedCell )
			{
				oCol.fnCreatedCell.call( oConfigurations.oInstance,
					nTd, _fnGetCellData( oConfigurations, iRow, i, 'display' ), oData._aData, iRow, i
				);
			}
		}

		_fnCallbackFire( oConfigurations, 'aoRowCreatedCallback', null, [oData.nTr, oData._aData, iRow] );
	}
}


/**
 * Create the HTML header for the table
 *  @param {object} oConfigurations dataTables configurations object
 *  @memberof DataTable#oApi
 */
function _fnBuildHead( oConfigurations )
{
	var i, nTh, iLen, j, jLen;
	var iThs = oConfigurations.nTHead.getElementsByTagName('th').length;
	var iCorrector = 0;
	var jqChildren;
	
	/* If there is a header in place - then use it - otherwise it's going to get nuked... */
	if ( iThs !== 0 )
	{
		/* We've got a thead from the DOM, so remove hidden columns and apply width to vis cols */
		for ( i=0, iLen=oConfigurations.aoColumns.length ; i<iLen ; i++ )
		{
			nTh = oConfigurations.aoColumns[i].nTh;
			nTh.setAttribute('role', 'columnheader');
			if ( oConfigurations.aoColumns[i].bSortable )
			{
				nTh.setAttribute('tabindex', oConfigurations.iTabIndex);
				nTh.setAttribute('aria-controls', oConfigurations.sTableId);
			}

			if ( oConfigurations.aoColumns[i].sClass !== null )
			{
				$(nTh).addClass( oConfigurations.aoColumns[i].sClass );
			}
			
			/* Set the title of the column if it is member defined (not what was auto detected) */
			if ( oConfigurations.aoColumns[i].sTitle != nTh.innerHTML )
			{
				nTh.innerHTML = oConfigurations.aoColumns[i].sTitle;
			}
		}
	}
	else
	{
		/* We don't have a header in the DOM - so we are going to have to create one */
		var nTr = document.createElement( "tr" );
		
		for ( i=0, iLen=oConfigurations.aoColumns.length ; i<iLen ; i++ )
		{
			nTh = oConfigurations.aoColumns[i].nTh;
			nTh.innerHTML = oConfigurations.aoColumns[i].sTitle;
			nTh.setAttribute('tabindex', '0');
			
			if ( oConfigurations.aoColumns[i].sClass !== null )
			{
				$(nTh).addClass( oConfigurations.aoColumns[i].sClass );
			}
			
			nTr.appendChild( nTh );
		}
		$(oConfigurations.nTHead).html( '' )[0].appendChild( nTr );
		_fnDetectHeader( oConfigurations.aoHeader, oConfigurations.nTHead );
	}
	
	/* ARIA role for the rows */	
	$(oConfigurations.nTHead).children('tr').attr('role', 'row');
	
	/* Add the extra markup needed by jQuery UI's themes */
	if ( oConfigurations.bJUI )
	{
		for ( i=0, iLen=oConfigurations.aoColumns.length ; i<iLen ; i++ )
		{
			nTh = oConfigurations.aoColumns[i].nTh;
			
			var nDiv = document.createElement('div');
			nDiv.className = oConfigurations.oClasses.sSortJUIWrapper;
			$(nTh).contents().appendTo(nDiv);
			
			var nSpan = document.createElement('span');
			nSpan.className = oConfigurations.oClasses.sSortIcon;
			nDiv.appendChild( nSpan );
			nTh.appendChild( nDiv );
		}
	}
	
	if ( oConfigurations.oFeatures.bSort )
	{
		for ( i=0 ; i<oConfigurations.aoColumns.length ; i++ )
		{
			if ( oConfigurations.aoColumns[i].bSortable !== false )
			{
				_fnSortAttachListener( oConfigurations, oConfigurations.aoColumns[i].nTh, i );
			}
			else
			{
				$(oConfigurations.aoColumns[i].nTh).addClass( oConfigurations.oClasses.sSortableNone );
			}
		}
	}
	
	/* Deal with the footer - add classes if required */
	if ( oConfigurations.oClasses.sFooterTH !== "" )
	{
		$(oConfigurations.nTFoot).children('tr').children('th').addClass( oConfigurations.oClasses.sFooterTH );
	}
	
	/* Cache the footer elements */
	if ( oConfigurations.nTFoot !== null )
	{
		var anCells = _fnGetUniqueThs( oConfigurations, null, oConfigurations.aoFooter );
		for ( i=0, iLen=oConfigurations.aoColumns.length ; i<iLen ; i++ )
		{
			if ( anCells[i] )
			{
				oConfigurations.aoColumns[i].nTf = anCells[i];
				if ( oConfigurations.aoColumns[i].sClass )
				{
					$(anCells[i]).addClass( oConfigurations.aoColumns[i].sClass );
				}
			}
		}
	}
}


/**
 * Draw the header (or footer) element based on the column visibility states. The
 * methodology here is to use the layout array from _fnDetectHeader, modified for
 * the instantaneous column visibility, to construct the new layout. The grid is
 * traversed over cell at a time in a rows x columns grid fashion, although each 
 * cell insert can cover multiple elements in the grid - which is tracks using the
 * aApplied array. Cell inserts in the grid will only occur where there isn't
 * already a cell in that position.
 *  @param {object} oConfigurations dataTables configurations object
 *  @param array {objects} aoSource Layout array from _fnDetectHeader
 *  @param {boolean} [bIncludeHidden=false] If true then include the hidden columns in the calc, 
 *  @memberof DataTable#oApi
 */
function _fnDrawHead( oConfigurations, aoSource, bIncludeHidden )
{
	var i, iLen, j, jLen, k, kLen, n, nLocalTr;
	var aoLocal = [];
	var aApplied = [];
	var iColumns = oConfigurations.aoColumns.length;
	var iRowspan, iColspan;

	if (  bIncludeHidden === undefined )
	{
		bIncludeHidden = false;
	}

	/* Make a copy of the master layout array, but without the visible columns in it */
	for ( i=0, iLen=aoSource.length ; i<iLen ; i++ )
	{
		aoLocal[i] = aoSource[i].slice();
		aoLocal[i].nTr = aoSource[i].nTr;

		/* Remove any columns which are currently hidden */
		for ( j=iColumns-1 ; j>=0 ; j-- )
		{
			if ( !oConfigurations.aoColumns[j].bVisible && !bIncludeHidden )
			{
				aoLocal[i].splice( j, 1 );
			}
		}

		/* Prep the applied array - it needs an element for each row */
		aApplied.push( [] );
	}

	for ( i=0, iLen=aoLocal.length ; i<iLen ; i++ )
	{
		nLocalTr = aoLocal[i].nTr;
		
		/* All cells are going to be replaced, so empty out the row */
		if ( nLocalTr )
		{
			while( (n = nLocalTr.firstChild) )
			{
				nLocalTr.removeChild( n );
			}
		}

		for ( j=0, jLen=aoLocal[i].length ; j<jLen ; j++ )
		{
			iRowspan = 1;
			iColspan = 1;

			/* Check to see if there is already a cell (row/colspan) covering our target
			 * insert point. If there is, then there is nothing to do.
			 */
			if ( aApplied[i][j] === undefined )
			{
				nLocalTr.appendChild( aoLocal[i][j].cell );
				aApplied[i][j] = 1;

				/* Expand the cell to cover as many rows as needed */
				while ( aoLocal[i+iRowspan] !== undefined &&
				        aoLocal[i][j].cell == aoLocal[i+iRowspan][j].cell )
				{
					aApplied[i+iRowspan][j] = 1;
					iRowspan++;
				}

				/* Expand the cell to cover as many columns as needed */
				while ( aoLocal[i][j+iColspan] !== undefined &&
				        aoLocal[i][j].cell == aoLocal[i][j+iColspan].cell )
				{
					/* Must update the applied array over the rows for the columns */
					for ( k=0 ; k<iRowspan ; k++ )
					{
						aApplied[i+k][j+iColspan] = 1;
					}
					iColspan++;
				}

				/* Do the actual expansion in the DOM */
				aoLocal[i][j].cell.rowSpan = iRowspan;
				aoLocal[i][j].cell.colSpan = iColspan;
			}
		}
	}
}


/**
 * Insert the required TR nodes into the table for display
 *  @param {object} oConfigurations dataTables configurations object
 *  @memberof DataTable#oApi
 */
function _fnDraw( oConfigurations )
{
	var i, iLen, n;
	var anRows = [];
	var iRowCount = 0;
	var iStripes = oConfigurations.asStripeClasses.length;
	var iOpenRows = oConfigurations.aoOpenRows.length;
	
	/* Provide a pre-callback function which can be used to cancel the draw is false is returned */
	var aPreDraw = _fnCallbackFire( oConfigurations, 'aoPreDrawCallback', 'preDraw', [oConfigurations] );
	if ( $.inArray( false, aPreDraw ) !== -1 )
	{
		return;
	}
	
	oConfigurations.bDrawing = true;
	
	/* Check and see if we have an initial draw position from state saving */
	if ( oConfigurations.iInitDisplayStart !== undefined && oConfigurations.iInitDisplayStart != -1 )
	{
		if ( oConfigurations.oFeatures.bServerSide )
		{
			oConfigurations._iDisplayStart = oConfigurations.iInitDisplayStart;
		}
		else
		{
			oConfigurations._iDisplayStart = (oConfigurations.iInitDisplayStart >= oConfigurations.fnRecordsDisplay()) ?
				0 : oConfigurations.iInitDisplayStart;
		}
		oConfigurations.iInitDisplayStart = -1;
		_fnCalculateEnd( oConfigurations );
	}
	
	/* Server-side processing draw intercept */
	if ( oConfigurations.bDeferLoading )
	{
		oConfigurations.bDeferLoading = false;
		oConfigurations.iDraw++;
	}
	else if ( !oConfigurations.oFeatures.bServerSide )
	{
		oConfigurations.iDraw++;
	}
	else if ( !oConfigurations.bDestroying && !_fnAjaxUpdate( oConfigurations ) )
	{
		return;
	}
	
	if ( oConfigurations.aiDisplay.length !== 0 )
	{
		var iStart = oConfigurations._iDisplayStart;
		var iEnd = oConfigurations._iDisplayEnd;
		
		if ( oConfigurations.oFeatures.bServerSide )
		{
			iStart = 0;
			iEnd = oConfigurations.aoData.length;
		}
		
		for ( var j=iStart ; j<iEnd ; j++ )
		{
			var aoData = oConfigurations.aoData[ oConfigurations.aiDisplay[j] ];
			if ( aoData.nTr === null )
			{
				_fnCreateTr( oConfigurations, oConfigurations.aiDisplay[j] );
			}

			var nRow = aoData.nTr;
			
			/* Remove the old striping classes and then add the new one */
			if ( iStripes !== 0 )
			{
				var sStripe = oConfigurations.asStripeClasses[ iRowCount % iStripes ];
				if ( aoData._sRowStripe != sStripe )
				{
					$(nRow).removeClass( aoData._sRowStripe ).addClass( sStripe );
					aoData._sRowStripe = sStripe;
				}
			}
			
			/* Row callback functions - might want to manipule the row */
			_fnCallbackFire( oConfigurations, 'aoRowCallback', null, 
				[nRow, oConfigurations.aoData[ oConfigurations.aiDisplay[j] ]._aData, iRowCount, j] );
			
			anRows.push( nRow );
			iRowCount++;
			
			/* If there is an open row - and it is attached to this parent - attach it on redraw */
			if ( iOpenRows !== 0 )
			{
				for ( var k=0 ; k<iOpenRows ; k++ )
				{
					if ( nRow == oConfigurations.aoOpenRows[k].nParent )
					{
						anRows.push( oConfigurations.aoOpenRows[k].nTr );
						break;
					}
				}
			}
		}
	}
	else
	{
		/* Table is empty - create a row with an empty message in it */
		anRows[ 0 ] = document.createElement( 'tr' );
		
		if ( oConfigurations.asStripeClasses[0] )
		{
			anRows[ 0 ].className = oConfigurations.asStripeClasses[0];
		}

		var sZero = oConfigurations.oLanguage.sZeroRecords.replace(
			'_MAX_', oConfigurations.fnFormatNumber(oConfigurations.fnRecordsTotal()) );
		if ( oConfigurations.iDraw == 1 && oConfigurations.sAjaxSource !== null && !oConfigurations.oFeatures.bServerSide )
		{
			sZero = oConfigurations.oLanguage.sLoadingRecords;
		}
		else if ( oConfigurations.oLanguage.sEmptyTable && oConfigurations.fnRecordsTotal() === 0 )
		{
			sZero = oConfigurations.oLanguage.sEmptyTable;
		}

		var nTd = document.createElement( 'td' );
		nTd.setAttribute( 'valign', "top" );
		nTd.colSpan = _fnVisbleColumns( oConfigurations );
		nTd.className = oConfigurations.oClasses.sRowEmpty;
		nTd.innerHTML = sZero;
		
		anRows[ iRowCount ].appendChild( nTd );
	}
	
	/* Header and footer callbacks */
	_fnCallbackFire( oConfigurations, 'aoHeaderCallback', 'header', [ $(oConfigurations.nTHead).children('tr')[0], 
		_fnGetDataMaster( oConfigurations ), oConfigurations._iDisplayStart, oConfigurations.fnDisplayEnd(), oConfigurations.aiDisplay ] );
	
	_fnCallbackFire( oConfigurations, 'aoFooterCallback', 'footer', [ $(oConfigurations.nTFoot).children('tr')[0], 
		_fnGetDataMaster( oConfigurations ), oConfigurations._iDisplayStart, oConfigurations.fnDisplayEnd(), oConfigurations.aiDisplay ] );
	
	/* 
	 * Need to remove any old row from the display - note we can't just empty the tbody using
	 * $().html('') since this will unbind the jQuery event handlers (even although the node 
	 * still exists!) - equally we can't use innerHTML, since IE throws an exception.
	 */
	var
		nAddFrag = document.createDocumentFragment(),
		nRemoveFrag = document.createDocumentFragment(),
		nBodyPar, nTrs;
	
	if ( oConfigurations.nTBody )
	{
		nBodyPar = oConfigurations.nTBody.parentNode;
		nRemoveFrag.appendChild( oConfigurations.nTBody );
		
		/* When doing infinite scrolling, only remove child rows when sorting, filtering or start
		 * up. When not infinite scroll, always do it.
		 */
		if ( !oConfigurations.oScroll.bInfinite || !oConfigurations._bInitComplete ||
		 	oConfigurations.bSorted || oConfigurations.bFiltered )
		{
			while( (n = oConfigurations.nTBody.firstChild) )
			{
				oConfigurations.nTBody.removeChild( n );
			}
		}
		
		/* Put the draw table into the dom */
		for ( i=0, iLen=anRows.length ; i<iLen ; i++ )
		{
			nAddFrag.appendChild( anRows[i] );
		}
		
		oConfigurations.nTBody.appendChild( nAddFrag );
		if ( nBodyPar !== null )
		{
			nBodyPar.appendChild( oConfigurations.nTBody );
		}
	}
	
	/* Call all required callback functions for the end of a draw */
	_fnCallbackFire( oConfigurations, 'aoDrawCallback', 'draw', [oConfigurations] );
	
	/* Draw is complete, sorting and filtering must be as well */
	oConfigurations.bSorted = false;
	oConfigurations.bFiltered = false;
	oConfigurations.bDrawing = false;
	
	if ( oConfigurations.oFeatures.bServerSide )
	{
		_fnProcessingDisplay( oConfigurations, false );
		if ( !oConfigurations._bInitComplete )
		{
			_fnInitComplete( oConfigurations );
		}
	}
}


/**
 * Redraw the table - taking account of the various features which are enabled
 *  @param {object} oConfigurations dataTables configurations object
 *  @memberof DataTable#oApi
 */
function _fnReDraw( oConfigurations )
{
	if ( oConfigurations.oFeatures.bSort )
	{
		/* Sorting will refilter and draw for us */
		_fnSort( oConfigurations, oConfigurations.oPreviousSearch );
	}
	else if ( oConfigurations.oFeatures.bFilter )
	{
		/* Filtering will redraw for us */
		_fnFilterComplete( oConfigurations, oConfigurations.oPreviousSearch );
	}
	else
	{
		_fnCalculateEnd( oConfigurations );
		_fnDraw( oConfigurations );
	}
}


/**
 * Add the options to the page HTML for the table
 *  @param {object} oConfigurations dataTables configurations object
 *  @memberof DataTable#oApi
 */
function _fnAddOptionsHtml ( oConfigurations )
{
	/*
	 * Create a temporary, empty, div which we can later on replace with what we have generated
	 * we do it this way to rendering the 'options' html offline - speed :-)
	 */
	var nHolding = $('<div></div>')[0];
	oConfigurations.nTable.parentNode.insertBefore( nHolding, oConfigurations.nTable );
	
	/* 
	 * All DataTables are wrapped in a div
	 */
	oConfigurations.nTableWrapper = $('<div id="'+oConfigurations.sTableId+'_wrapper" class="'+oConfigurations.oClasses.sWrapper+'" role="grid"></div>')[0];
	oConfigurations.nTableReinsertBefore = oConfigurations.nTable.nextSibling;

	/* Track where we want to insert the option */
	var nInsertNode = oConfigurations.nTableWrapper;
	
	/* Loop over the member set positioning and place the elements as needed */
	var aDom = oConfigurations.sDom.split('');
	var nTmp, iPushFeature, cOption, nNewNode, cNext, sAttr, j;
	for ( var i=0 ; i<aDom.length ; i++ )
	{
		iPushFeature = 0;
		cOption = aDom[i];
		
		if ( cOption == '<' )
		{
			/* New container div */
			nNewNode = $('<div></div>')[0];
			
			/* Check to see if we should append an id and/or a class name to the container */
			cNext = aDom[i+1];
			if ( cNext == "'" || cNext == '"' )
			{
				sAttr = "";
				j = 2;
				while ( aDom[i+j] != cNext )
				{
					sAttr += aDom[i+j];
					j++;
				}
				
				/* Replace jQuery UI constants */
				if ( sAttr == "H" )
				{
					sAttr = "fg-toolbar ui-toolbar ui-widget-header ui-corner-tl ui-corner-tr ui-helper-clearfix";
				}
				else if ( sAttr == "F" )
				{
					sAttr = "fg-toolbar ui-toolbar ui-widget-header ui-corner-bl ui-corner-br ui-helper-clearfix";
				}
				
				/* The attribute can be in the format of "#id.class", "#id" or "class" This logic
				 * breaks the string into parts and applies them as needed
				 */
				if ( sAttr.indexOf('.') != -1 )
				{
					var aSplit = sAttr.split('.');
					nNewNode.id = aSplit[0].substr(1, aSplit[0].length-1);
					nNewNode.className = aSplit[1];
				}
				else if ( sAttr.charAt(0) == "#" )
				{
					nNewNode.id = sAttr.substr(1, sAttr.length-1);
				}
				else
				{
					nNewNode.className = sAttr;
				}
				
				i += j; /* Move along the position array */
			}
			
			nInsertNode.appendChild( nNewNode );
			nInsertNode = nNewNode;
		}
		else if ( cOption == '>' )
		{
			/* End container div */
			nInsertNode = nInsertNode.parentNode;
		}
		else if ( cOption == 'l' && oConfigurations.oFeatures.bPaginate && oConfigurations.oFeatures.bLengthChange )
		{
			/* Length */
			nTmp = _fnFeatureHtmlLength( oConfigurations );
			iPushFeature = 1;
		}
		else if ( cOption == 'f' && oConfigurations.oFeatures.bFilter )
		{
			/* Filter */
			nTmp = _fnFeatureHtmlFilter( oConfigurations );
			iPushFeature = 1;
		}
		else if ( cOption == 'r' && oConfigurations.oFeatures.bProcessing )
		{
			/* pRocessing */
			nTmp = _fnFeatureHtmlProcessing( oConfigurations );
			iPushFeature = 1;
		}
		else if ( cOption == 't' )
		{
			/* Table */
			nTmp = _fnFeatureHtmlTable( oConfigurations );
			iPushFeature = 1;
		}
		else if ( cOption ==  'i' && oConfigurations.oFeatures.bInfo )
		{
			/* Info */
			nTmp = _fnFeatureHtmlInfo( oConfigurations );
			iPushFeature = 1;
		}
		else if ( cOption == 'p' && oConfigurations.oFeatures.bPaginate )
		{
			/* Pagination */
			nTmp = _fnFeatureHtmlPaginate( oConfigurations );
			iPushFeature = 1;
		}
		else if ( DataTable.ext.aoFeatures.length !== 0 )
		{
			/* Plug-in features */
			var aoFeatures = DataTable.ext.aoFeatures;
			for ( var k=0, kLen=aoFeatures.length ; k<kLen ; k++ )
			{
				if ( cOption == aoFeatures[k].cFeature )
				{
					nTmp = aoFeatures[k].fnInit( oConfigurations );
					if ( nTmp )
					{
						iPushFeature = 1;
					}
					break;
				}
			}
		}
		
		/* Add to the 2D features array */
		if ( iPushFeature == 1 && nTmp !== null )
		{
			if ( typeof oConfigurations.aanFeatures[cOption] !== 'object' )
			{
				oConfigurations.aanFeatures[cOption] = [];
			}
			oConfigurations.aanFeatures[cOption].push( nTmp );
			nInsertNode.appendChild( nTmp );
		}
	}
	
	/* Built our DOM structure - replace the holding div with what we want */
	nHolding.parentNode.replaceChild( oConfigurations.nTableWrapper, nHolding );
}


/**
 * Use the DOM source to create up an array of header cells. The idea here is to
 * create a layout grid (array) of rows x columns, which contains a reference
 * to the cell that that point in the grid (regardless of col/rowspan), such that
 * any column / row could be removed and the new grid constructed
 *  @param array {object} aLayout Array to store the calculated layout in
 *  @param {node} nThead The header/footer element for the table
 *  @memberof DataTable#oApi
 */
function _fnDetectHeader ( aLayout, nThead )
{
	var nTrs = $(nThead).children('tr');
	var nCell;
	var i, j, k, l, iLen, jLen, iColShifted;
	var fnShiftCol = function ( a, i, j ) {
		while ( a[i][j] ) {
			j++;
		}
		return j;
	};

	aLayout.splice( 0, aLayout.length );
	
	/* We know how many rows there are in the layout - so prep it */
	for ( i=0, iLen=nTrs.length ; i<iLen ; i++ )
	{
		aLayout.push( [] );
	}
	
	/* Calculate a layout array */
	for ( i=0, iLen=nTrs.length ; i<iLen ; i++ )
	{
		var iColumn = 0;
		
		/* For every cell in the row... */
		for ( j=0, jLen=nTrs[i].childNodes.length ; j<jLen ; j++ )
		{
			nCell = nTrs[i].childNodes[j];

			if ( nCell.nodeName.toUpperCase() == "TD" ||
			     nCell.nodeName.toUpperCase() == "TH" )
			{
				/* Get the col and rowspan attributes from the DOM and sanitise them */
				var iColspan = nCell.getAttribute('colspan') * 1;
				var iRowspan = nCell.getAttribute('rowspan') * 1;
				iColspan = (!iColspan || iColspan===0 || iColspan===1) ? 1 : iColspan;
				iRowspan = (!iRowspan || iRowspan===0 || iRowspan===1) ? 1 : iRowspan;

				/* There might be colspan cells already in this row, so shift our target 
				 * accordingly
				 */
				iColShifted = fnShiftCol( aLayout, i, iColumn );
				
				/* If there is col / rowspan, copy the information into the layout grid */
				for ( l=0 ; l<iColspan ; l++ )
				{
					for ( k=0 ; k<iRowspan ; k++ )
					{
						aLayout[i+k][iColShifted+l] = {
							"cell": nCell,
							"unique": iColspan == 1 ? true : false
						};
						aLayout[i+k].nTr = nTrs[i];
					}
				}
			}
		}
	}
}


/**
 * Get an array of unique th elements, one for each column
 *  @param {object} oConfigurations dataTables configurations object
 *  @param {node} nHeader automatically detect the layout from this node - optional
 *  @param {array} aLayout thead/tfoot layout from _fnDetectHeader - optional
 *  @returns array {node} aReturn list of unique ths
 *  @memberof DataTable#oApi
 */
function _fnGetUniqueThs ( oConfigurations, nHeader, aLayout )
{
	var aReturn = [];
	if ( !aLayout )
	{
		aLayout = oConfigurations.aoHeader;
		if ( nHeader )
		{
			aLayout = [];
			_fnDetectHeader( aLayout, nHeader );
		}
	}

	for ( var i=0, iLen=aLayout.length ; i<iLen ; i++ )
	{
		for ( var j=0, jLen=aLayout[i].length ; j<jLen ; j++ )
		{
			if ( aLayout[i][j].unique && 
				 (!aReturn[j] || !oConfigurations.bSortCellsTop) )
			{
				aReturn[j] = aLayout[i][j].cell;
			}
		}
	}
	
	return aReturn;
}

