

/**
 * Update the table using an Ajax call
 *  @param {object} oConfigurations dataTables configurations object
 *  @returns {boolean} Block the table drawing or not
 *  @memberof DataTable#oApi
 */
function _fnAjaxUpdate( oConfigurations )
{
	if ( oConfigurations.bAjaxDataGet )
	{
		oConfigurations.iDraw++;
		_fnProcessingDisplay( oConfigurations, true );
		var iColumns = oConfigurations.aoColumns.length;
		var aoData = _fnAjaxParameters( oConfigurations );
		_fnServerParams( oConfigurations, aoData );
		
		oConfigurations.fnServerData.call( oConfigurations.oInstance, oConfigurations.sAjaxSource, aoData,
			function(json) {
				_fnAjaxUpdateDraw( oConfigurations, json );
			}, oConfigurations );
		return false;
	}
	else
	{
		return true;
	}
}


/**
 * Build up the parameters in an object needed for a server-side processing request
 *  @param {object} oConfigurations dataTables configurations object
 *  @returns {bool} block the table drawing or not
 *  @memberof DataTable#oApi
 */
function _fnAjaxParameters( oConfigurations )
{
	var iColumns = oConfigurations.aoColumns.length;
	var aoData = [], mDataProp;
	var i;
	
	aoData.push( { "name": "sEcho",          "value": oConfigurations.iDraw } );
	aoData.push( { "name": "iColumns",       "value": iColumns } );
	aoData.push( { "name": "sColumns",       "value": _fnColumnOrdering(oConfigurations) } );
	aoData.push( { "name": "iDisplayStart",  "value": oConfigurations._iDisplayStart } );
	aoData.push( { "name": "iDisplayLength", "value": oConfigurations.oFeatures.bPaginate !== false ?
		oConfigurations._iDisplayLength : -1 } );
		
	for ( i=0 ; i<iColumns ; i++ )
	{
	  mDataProp = oConfigurations.aoColumns[i].mDataProp;
		aoData.push( { "name": "mDataProp_"+i, "value": typeof(mDataProp)==="function" ? 'function' : mDataProp } );
	}
	
	/* Filtering */
	if ( oConfigurations.oFeatures.bFilter !== false )
	{
		aoData.push( { "name": "sSearch", "value": oConfigurations.oPreviousSearch.sSearch } );
		aoData.push( { "name": "bRegex",  "value": oConfigurations.oPreviousSearch.bRegex } );
		for ( i=0 ; i<iColumns ; i++ )
		{
			aoData.push( { "name": "sSearch_"+i,     "value": oConfigurations.aoPreSearchCols[i].sSearch } );
			aoData.push( { "name": "bRegex_"+i,      "value": oConfigurations.aoPreSearchCols[i].bRegex } );
			aoData.push( { "name": "bSearchable_"+i, "value": oConfigurations.aoColumns[i].bSearchable } );
		}
	}
	
	/* Sorting */
	if ( oConfigurations.oFeatures.bSort !== false )
	{
		var iFixed = oConfigurations.aaSortingFixed !== null ? oConfigurations.aaSortingFixed.length : 0;
		var iMember = oConfigurations.aaSorting.length;
		aoData.push( { "name": "iSortingCols",   "value": iFixed+iMember } );
		for ( i=0 ; i<iFixed ; i++ )
		{
			aoData.push( { "name": "iSortCol_"+i,  "value": oConfigurations.aaSortingFixed[i][0] } );
			aoData.push( { "name": "sSortDir_"+i,  "value": oConfigurations.aaSortingFixed[i][1] } );
		}
		
		for ( i=0 ; i<iMember ; i++ )
		{
			aoData.push( { "name": "iSortCol_"+(i+iFixed),  "value": oConfigurations.aaSorting[i][0] } );
			aoData.push( { "name": "sSortDir_"+(i+iFixed),  "value": oConfigurations.aaSorting[i][1] } );
		}
		
		for ( i=0 ; i<iColumns ; i++ )
		{
			aoData.push( { "name": "bSortable_"+i,  "value": oConfigurations.aoColumns[i].bSortable } );
		}
	}
	
	return aoData;
}


/**
 * Add Ajax parameters from plugins
 *  @param {object} oConfigurations dataTables configurations object
 *  @param array {objects} aoData name/value pairs to send to the server
 *  @memberof DataTable#oApi
 */
function _fnServerParams( oConfigurations, aoData )
{
	_fnCallbackFire( oConfigurations, 'aoServerParams', 'serverParams', [aoData] );
}


/**
 * Data the data from the server (nuking the old) and redraw the table
 *  @param {object} oConfigurations dataTables configurations object
 *  @param {object} json json data return from the server.
 *  @param {string} json.sEcho Tracking flag for DataTables to match requests
 *  @param {int} json.iTotalRecords Number of records in the data set, not accounting for filtering
 *  @param {int} json.iTotalDisplayRecords Number of records in the data set, accounting for filtering
 *  @param {array} json.aaData The data to display on this page
 *  @param {string} [json.sColumns] Column ordering (sName, comma separated)
 *  @memberof DataTable#oApi
 */
function _fnAjaxUpdateDraw ( oConfigurations, json )
{
	if ( json.sEcho !== undefined )
	{
		/* Protect against old returns over-writing a new one. Possible when you get
		 * very fast interaction, and later queires are completed much faster
		 */
		if ( json.sEcho*1 < oConfigurations.iDraw )
		{
			return;
		}
		else
		{
			oConfigurations.iDraw = json.sEcho * 1;
		}
	}
	
	if ( !oConfigurations.oScroll.bInfinite ||
		   (oConfigurations.oScroll.bInfinite && (oConfigurations.bSorted || oConfigurations.bFiltered)) )
	{
		_fnClearTable( oConfigurations );
	}
	oConfigurations._iRecordsTotal = parseInt(json.iTotalRecords, 10);
	oConfigurations._iRecordsDisplay = parseInt(json.iTotalDisplayRecords, 10);
	
	/* Determine if reordering is required */
	var sOrdering = _fnColumnOrdering(oConfigurations);
	var bReOrder = (json.sColumns !== undefined && sOrdering !== "" && json.sColumns != sOrdering );
	var aiIndex;
	if ( bReOrder )
	{
		aiIndex = _fnReOrderIndex( oConfigurations, json.sColumns );
	}
	
	var aData = _fnGetObjectDataFn( oConfigurations.sAjaxDataProp )( json );
	for ( var i=0, iLen=aData.length ; i<iLen ; i++ )
	{
		if ( bReOrder )
		{
			/* If we need to re-order, then create a new array with the correct order and add it */
			var aDataSorted = [];
			for ( var j=0, jLen=oConfigurations.aoColumns.length ; j<jLen ; j++ )
			{
				aDataSorted.push( aData[i][ aiIndex[j] ] );
			}
			_fnAddData( oConfigurations, aDataSorted );
		}
		else
		{
			/* No re-order required, sever got it "right" - just straight add */
			_fnAddData( oConfigurations, aData[i] );
		}
	}
	oConfigurations.aiDisplay = oConfigurations.aiDisplayMaster.slice();
	
	oConfigurations.bAjaxDataGet = false;
	_fnDraw( oConfigurations );
	oConfigurations.bAjaxDataGet = true;
	_fnProcessingDisplay( oConfigurations, false );
}

