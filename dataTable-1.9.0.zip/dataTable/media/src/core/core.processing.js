

/**
 * Generate the node required for the processing node
 *  @param {object} oConfigurations dataTables configurations object
 *  @returns {node} Processing element
 *  @memberof DataTable#oApi
 */
function _fnFeatureHtmlProcessing ( oConfigurations )
{
	var nProcessing = document.createElement( 'div' );
	
	if ( !oConfigurations.aanFeatures.r )
	{
		nProcessing.id = oConfigurations.sTableId+'_processing';
	}
	nProcessing.innerHTML = oConfigurations.oLanguage.sProcessing;
	nProcessing.className = oConfigurations.oClasses.sProcessing;
	oConfigurations.nTable.parentNode.insertBefore( nProcessing, oConfigurations.nTable );
	
	return nProcessing;
}


/**
 * Display or hide the processing indicator
 *  @param {object} oConfigurations dataTables configurations object
 *  @param {bool} bShow Show the processing indicator (true) or not (false)
 *  @memberof DataTable#oApi
 */
function _fnProcessingDisplay ( oConfigurations, bShow )
{
	if ( oConfigurations.oFeatures.bProcessing )
	{
		var an = oConfigurations.aanFeatures.r;
		for ( var i=0, iLen=an.length ; i<iLen ; i++ )
		{
			an[i].style.visibility = bShow ? "visible" : "hidden";
		}
	}

	$(oConfigurations.oInstance).trigger('processing', [oConfigurations, bShow]);
}

