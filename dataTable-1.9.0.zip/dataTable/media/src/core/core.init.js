

/**
 * Draw the table for the first time, adding all required features
 *  @param {object} oConfigurations dataTables configurations object
 *  @memberof DataTable#oApi
 */
function _fnInitialise ( oConfigurations )
{
	var i, iLen, iAjaxStart=oConfigurations.iInitDisplayStart;
	
	/* Ensure that the table data is fully initialised */
	if ( oConfigurations.bInitialised === false )
	{
		setTimeout( function(){ _fnInitialise( oConfigurations ); }, 200 );
		return;
	}
	
	/* Show the display HTML options */
	_fnAddOptionsHtml( oConfigurations );
	
	/* Build and draw the header / footer for the table */
	_fnBuildHead( oConfigurations );
	_fnDrawHead( oConfigurations, oConfigurations.aoHeader );
	if ( oConfigurations.nTFoot )
	{
		_fnDrawHead( oConfigurations, oConfigurations.aoFooter );
	}

	/* Okay to show that something is going on now */
	_fnProcessingDisplay( oConfigurations, true );
	
	/* Calculate sizes for columns */
	if ( oConfigurations.oFeatures.bAutoWidth )
	{
		_fnCalculateColumnWidths( oConfigurations );
	}
	
	for ( i=0, iLen=oConfigurations.aoColumns.length ; i<iLen ; i++ )
	{
		if ( oConfigurations.aoColumns[i].sWidth !== null )
		{
			oConfigurations.aoColumns[i].nTh.style.width = _fnStringToCss( oConfigurations.aoColumns[i].sWidth );
		}
	}
	
	/* If there is default sorting required - let's do it. The sort function will do the
	 * drawing for us. Otherwise we draw the table regardless of the Ajax source - this allows
	 * the table to look initialised for Ajax sourcing data (show 'loading' message possibly)
	 */
	if ( oConfigurations.oFeatures.bSort )
	{
		_fnSort( oConfigurations );
	}
	else if ( oConfigurations.oFeatures.bFilter )
	{
		_fnFilterComplete( oConfigurations, oConfigurations.oPreviousSearch );
	}
	else
	{
		oConfigurations.aiDisplay = oConfigurations.aiDisplayMaster.slice();
		_fnCalculateEnd( oConfigurations );
		_fnDraw( oConfigurations );
	}
	
	/* if there is an ajax source load the data */
	if ( oConfigurations.sAjaxSource !== null && !oConfigurations.oFeatures.bServerSide )
	{
		var aoData = [];
		_fnServerParams( oConfigurations, aoData );
		oConfigurations.fnServerData.call( oConfigurations.oInstance, oConfigurations.sAjaxSource, aoData, function(json) {
			var aData = (oConfigurations.sAjaxDataProp !== "") ?
			 	_fnGetObjectDataFn( oConfigurations.sAjaxDataProp )(json) : json;

			/* Got the data - add it to the table */
			for ( i=0 ; i<aData.length ; i++ )
			{
				_fnAddData( oConfigurations, aData[i] );
			}
			
			/* Reset the init display for cookie saving. We've already done a filter, and
			 * therefore cleared it before. So we need to make it appear 'fresh'
			 */
			oConfigurations.iInitDisplayStart = iAjaxStart;
			
			if ( oConfigurations.oFeatures.bSort )
			{
				_fnSort( oConfigurations );
			}
			else
			{
				oConfigurations.aiDisplay = oConfigurations.aiDisplayMaster.slice();
				_fnCalculateEnd( oConfigurations );
				_fnDraw( oConfigurations );
			}
			
			_fnProcessingDisplay( oConfigurations, false );
			_fnInitComplete( oConfigurations, json );
		}, oConfigurations );
		return;
	}
	
	/* Server-side processing initialisation complete is done at the end of _fnDraw */
	if ( !oConfigurations.oFeatures.bServerSide )
	{
		_fnProcessingDisplay( oConfigurations, false );
		_fnInitComplete( oConfigurations );
	}
}


/**
 * Draw the table for the first time, adding all required features
 *  @param {object} oConfigurations dataTables configurations object
 *  @param {object} [json] JSON from the server that completed the table, if using Ajax source
 *    with client-side processing (optional)
 *  @memberof DataTable#oApi
 */
function _fnInitComplete ( oConfigurations, json )
{
	oConfigurations._bInitComplete = true;
	_fnCallbackFire( oConfigurations, 'aoInitComplete', 'init', [oConfigurations, json] );
}


/**
 * Language compatibility - when certain options are given, and others aren't, we
 * need to duplicate the values over, in order to provide backwards compatibility
 * with older language files.
 *  @param {object} oConfigurations dataTables configurations object
 *  @memberof DataTable#oApi
 */
function _fnLanguageCompat( oLanguage )
{
	/* Backwards compatibility - if there is no sEmptyTable given, then use the same as
	 * sZeroRecords - assuming that is given.
	 */
	if ( !oLanguage.sEmptyTable && oLanguage.sZeroRecords )
	{
		_fnMap( oLanguage, oLanguage, 'sZeroRecords', 'sEmptyTable' );
	}

	/* Likewise with loading records */
	if ( !oLanguage.sLoadingRecords && oLanguage.sZeroRecords )
	{
		_fnMap( oLanguage, oLanguage, 'sZeroRecords', 'sLoadingRecords' );
	}
}

