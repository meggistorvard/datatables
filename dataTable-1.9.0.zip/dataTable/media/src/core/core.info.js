

/**
 * Generate the node required for the info display
 *  @param {object} oConfigurations dataTables configurations object
 *  @returns {node} Information element
 *  @memberof DataTable#oApi
 */
function _fnFeatureHtmlInfo ( oConfigurations )
{
	var nInfo = document.createElement( 'div' );
	nInfo.className = oConfigurations.oClasses.sInfo;
	
	/* Actions that are to be taken once only for this feature */
	if ( !oConfigurations.aanFeatures.i )
	{
		/* Add draw callback */
		oConfigurations.aoDrawCallback.push( {
			"fn": _fnUpdateInfo,
			"sName": "information"
		} );
		
		/* Add id */
		nInfo.id = oConfigurations.sTableId+'_info';
	}
	oConfigurations.nTable.setAttribute( 'aria-describedby', oConfigurations.sTableId+'_info' );
	
	return nInfo;
}


/**
 * Update the information elements in the display
 *  @param {object} oConfigurations dataTables configurations object
 *  @memberof DataTable#oApi
 */
function _fnUpdateInfo ( oConfigurations )
{
	/* Show information about the table */
	if ( !oConfigurations.oFeatures.bInfo || oConfigurations.aanFeatures.i.length === 0 )
	{
		return;
	}
	
	var
		iStart = oConfigurations._iDisplayStart+1, iEnd = oConfigurations.fnDisplayEnd(),
		iMax = oConfigurations.fnRecordsTotal(), iTotal = oConfigurations.fnRecordsDisplay(),
		sStart = oConfigurations.fnFormatNumber( iStart ), sEnd = oConfigurations.fnFormatNumber( iEnd ),
		sMax = oConfigurations.fnFormatNumber( iMax ), sTotal = oConfigurations.fnFormatNumber( iTotal ),
		sOut;
	
	/* When infinite scrolling, we are always starting at 1. _iDisplayStart is used only
	 * internally
	 */
	if ( oConfigurations.oScroll.bInfinite )
	{
		sStart = oConfigurations.fnFormatNumber( 1 );
	}
	
	if ( oConfigurations.fnRecordsDisplay() === 0 && 
		   oConfigurations.fnRecordsDisplay() == oConfigurations.fnRecordsTotal() )
	{
		/* Empty record set */
		sOut = oConfigurations.oLanguage.sInfoEmpty+ oConfigurations.oLanguage.sInfoPostFix;
	}
	else if ( oConfigurations.fnRecordsDisplay() === 0 )
	{
		/* Rmpty record set after filtering */
		sOut = oConfigurations.oLanguage.sInfoEmpty +' '+ 
			oConfigurations.oLanguage.sInfoFiltered.replace('_MAX_', sMax)+
				oConfigurations.oLanguage.sInfoPostFix;
	}
	else if ( oConfigurations.fnRecordsDisplay() == oConfigurations.fnRecordsTotal() )
	{
		/* Normal record set */
		sOut = oConfigurations.oLanguage.sInfo.
				replace('_START_', sStart).
				replace('_END_',   sEnd).
				replace('_TOTAL_', sTotal)+ 
			oConfigurations.oLanguage.sInfoPostFix;
	}
	else
	{
		/* Record set after filtering */
		sOut = oConfigurations.oLanguage.sInfo.
				replace('_START_', sStart).
				replace('_END_',   sEnd).
				replace('_TOTAL_', sTotal) +' '+ 
			oConfigurations.oLanguage.sInfoFiltered.replace('_MAX_', 
				oConfigurations.fnFormatNumber(oConfigurations.fnRecordsTotal()))+ 
			oConfigurations.oLanguage.sInfoPostFix;
	}
	
	if ( oConfigurations.oLanguage.fnInfoCallback !== null )
	{
		sOut = oConfigurations.oLanguage.fnInfoCallback.call( oConfigurations.oInstance, 
			oConfigurations, iStart, iEnd, iMax, iTotal, sOut );
	}
	
	var n = oConfigurations.aanFeatures.i;
	for ( var i=0, iLen=n.length ; i<iLen ; i++ )
	{
		$(n[i]).html( sOut );
	}
}

