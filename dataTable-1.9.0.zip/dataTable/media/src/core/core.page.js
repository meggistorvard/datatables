

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Note that most of the paging logic is done in 
 * DataTable.ext.oPagination
 */

/**
 * Generate the node required for default pagination
 *  @param {object} oConfigurations dataTables configurations object
 *  @returns {node} Pagination feature node
 *  @memberof DataTable#oApi
 */
function _fnFeatureHtmlPaginate ( oConfigurations )
{
	if ( oConfigurations.oScroll.bInfinite )
	{
		return null;
	}
	
	var nPaginate = document.createElement( 'div' );
	nPaginate.className = oConfigurations.oClasses.sPaging+oConfigurations.sPaginationType;
	
	DataTable.ext.oPagination[ oConfigurations.sPaginationType ].fnInit( oConfigurations, nPaginate, 
		function( oConfigurations ) {
			_fnCalculateEnd( oConfigurations );
			_fnDraw( oConfigurations );
		}
	);
	
	/* Add a draw callback for the pagination on first instance, to update the paging display */
	if ( !oConfigurations.aanFeatures.p )
	{
		oConfigurations.aoDrawCallback.push( {
			"fn": function( oConfigurations ) {
				DataTable.ext.oPagination[ oConfigurations.sPaginationType ].fnUpdate( oConfigurations, function( oConfigurations ) {
					_fnCalculateEnd( oConfigurations );
					_fnDraw( oConfigurations );
				} );
			},
			"sName": "pagination"
		} );
	}
	return nPaginate;
}


/**
 * Alter the display configurations to change the page
 *  @param {object} oConfigurations dataTables configurations object
 *  @param {string|int} mAction Paging action to take: "first", "previous", "next" or "last"
 *    or page number to jump to (integer)
 *  @returns {bool} true page has changed, false - no change (no effect) eg 'first' on page 1
 *  @memberof DataTable#oApi
 */
function _fnPageChange ( oConfigurations, mAction )
{
	var iOldStart = oConfigurations._iDisplayStart;
	
	if ( typeof mAction === "number" )
	{
		oConfigurations._iDisplayStart = mAction * oConfigurations._iDisplayLength;
		if ( oConfigurations._iDisplayStart > oConfigurations.fnRecordsDisplay() )
		{
			oConfigurations._iDisplayStart = 0;
		}
	}
	else if ( mAction == "first" )
	{
		oConfigurations._iDisplayStart = 0;
	}
	else if ( mAction == "previous" )
	{
		oConfigurations._iDisplayStart = oConfigurations._iDisplayLength>=0 ?
			oConfigurations._iDisplayStart - oConfigurations._iDisplayLength :
			0;
		
		/* Correct for underrun */
		if ( oConfigurations._iDisplayStart < 0 )
		{
		  oConfigurations._iDisplayStart = 0;
		}
	}
	else if ( mAction == "next" )
	{
		if ( oConfigurations._iDisplayLength >= 0 )
		{
			/* Make sure we are not over running the display array */
			if ( oConfigurations._iDisplayStart + oConfigurations._iDisplayLength < oConfigurations.fnRecordsDisplay() )
			{
				oConfigurations._iDisplayStart += oConfigurations._iDisplayLength;
			}
		}
		else
		{
			oConfigurations._iDisplayStart = 0;
		}
	}
	else if ( mAction == "last" )
	{
		if ( oConfigurations._iDisplayLength >= 0 )
		{
			var iPages = parseInt( (oConfigurations.fnRecordsDisplay()-1) / oConfigurations._iDisplayLength, 10 ) + 1;
			oConfigurations._iDisplayStart = (iPages-1) * oConfigurations._iDisplayLength;
		}
		else
		{
			oConfigurations._iDisplayStart = 0;
		}
	}
	else
	{
		_fnLog( oConfigurations, 0, "Unknown paging action: "+mAction );
	}
	$(oConfigurations.oInstance).trigger('page', oConfigurations);
	
	return iOldStart != oConfigurations._iDisplayStart;
}

