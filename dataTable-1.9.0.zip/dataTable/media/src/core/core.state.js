

/**
 * Save the state of a table in a cookie such that the page can be reloaded
 *  @param {object} oConfigurations dataTables configurations object
 *  @memberof DataTable#oApi
 */
function _fnSaveState ( oConfigurations )
{
	if ( !oConfigurations.oFeatures.bStateSave || oConfigurations.bDestroying )
	{
		return;
	}

	/* Store the interesting variables */
	var i, iLen, bInfinite=oConfigurations.oScroll.bInfinite;
	var oState = {
		"iCreate":      new Date().getTime(),
		"iStart":       (bInfinite ? 0 : oConfigurations._iDisplayStart),
		"iEnd":         (bInfinite ? oConfigurations._iDisplayLength : oConfigurations._iDisplayEnd),
		"iLength":      oConfigurations._iDisplayLength,
		"aaSorting":    $.extend( true, [], oConfigurations.aaSorting ),
		"oSearch":      $.extend( true, {}, oConfigurations.oPreviousSearch ),
		"aoSearchCols": $.extend( true, [], oConfigurations.aoPreSearchCols ),
		"abVisCols":    []
	};

	for ( i=0, iLen=oConfigurations.aoColumns.length ; i<iLen ; i++ )
	{
		oState.abVisCols.push( oConfigurations.aoColumns[i].bVisible );
	}

	_fnCallbackFire( oConfigurations, "aoStateSaveParams", 'stateSaveParams', [oConfigurations, oState] );
	
	oConfigurations.fnStateSave.call( oConfigurations.oInstance, oConfigurations, oState );
}


/**
 * Attempt to load a saved table state from a cookie
 *  @param {object} oConfigurations dataTables configurations object
 *  @param {object} oInit DataTables init object so we can override configurations
 *  @memberof DataTable#oApi
 */
function _fnLoadState ( oConfigurations, oInit )
{
	if ( !oConfigurations.oFeatures.bStateSave )
	{
		return;
	}

	var oData = oConfigurations.fnStateLoad.call( oConfigurations.oInstance, oConfigurations );
	if ( !oData )
	{
		return;
	}
	
	/* Allow custom and plug-in manipulation functions to alter the saved data set and
	 * cancelling of loading by returning false
	 */
	var abStateLoad = _fnCallbackFire( oConfigurations, 'aoStateLoadParams', 'stateLoadParams', [oConfigurations, oData] );
	if ( $.inArray( false, abStateLoad ) !== -1 )
	{
		return;
	}
	
	/* Store the saved state so it might be accessed at any time */
	oConfigurations.oLoadedState = $.extend( true, {}, oData );
	
	/* Restore key features */
	oConfigurations._iDisplayStart    = oData.iStart;
	oConfigurations.iInitDisplayStart = oData.iStart;
	oConfigurations._iDisplayEnd      = oData.iEnd;
	oConfigurations._iDisplayLength   = oData.iLength;
	oConfigurations.aaSorting         = oData.aaSorting.slice();
	oConfigurations.saved_aaSorting   = oData.aaSorting.slice();
	
	/* Search filtering  */
	$.extend( oConfigurations.oPreviousSearch, oData.oSearch );
	$.extend( true, oConfigurations.aoPreSearchCols, oData.aoSearchCols );
	
	/* Column visibility state
	 * Pass back visibiliy configurations to the init handler, but to do not here override
	 * the init object that the member might have passed in
	 */
	oInit.saved_aoColumns = [];
	for ( var i=0 ; i<oData.abVisCols.length ; i++ )
	{
		oInit.saved_aoColumns[i] = {};
		oInit.saved_aoColumns[i].bVisible = oData.abVisCols[i];
	}

	_fnCallbackFire( oConfigurations, 'aoStateLoaded', 'stateLoaded', [oConfigurations, oData] );
}


/**
 * Create a new cookie with a value to store the state of a table
 *  @param {string} sName name of the cookie to create
 *  @param {string} sValue the value the cookie should take
 *  @param {int} iSecs duration of the cookie
 *  @param {string} sBaseName sName is made up of the base + file name - this is the base
 *  @param {function} fnCallback Member definable function to modify the cookie
 *  @memberof DataTable#oApi
 */
function _fnCreateCookie ( sName, sValue, iSecs, sBaseName, fnCallback )
{
	var date = new Date();
	date.setTime( date.getTime()+(iSecs*1000) );
	
	/* 
	 * Shocking but true - it would appear IE has major issues with having the path not having
	 * a trailing slash on it. We need the cookie to be available based on the path, so we
	 * have to append the file name to the cookie name. Appalling. Thanks to vex for adding the
	 * patch to use at least some of the path
	 */
	var aParts = window.location.pathname.split('/');
	var sNameFile = sName + '_' + aParts.pop().replace(/[\/:]/g,"").toLowerCase();
	var sFullCookie, oData;
	
	if ( fnCallback !== null )
	{
		oData = (typeof $.parseJSON === 'function') ? 
			$.parseJSON( sValue ) : eval( '('+sValue+')' );
		sFullCookie = fnCallback( sNameFile, oData, date.toGMTString(),
			aParts.join('/')+"/" );
	}
	else
	{
		sFullCookie = sNameFile + "=" + encodeURIComponent(sValue) +
			"; expires=" + date.toGMTString() +"; path=" + aParts.join('/')+"/";
	}
	
	/* Are we going to go over the cookie limit of 4KiB? If so, try to delete a cookies
	 * belonging to DataTables. This is FAR from bullet proof
	 */
	var sOldName="", iOldTime=9999999999999;
	var iLength = _fnReadCookie( sNameFile )!==null ? document.cookie.length : 
		sFullCookie.length + document.cookie.length;
	
	if ( iLength+10 > 4096 ) /* Magic 10 for padding */
	{
		var aCookies =document.cookie.split(';');
		for ( var i=0, iLen=aCookies.length ; i<iLen ; i++ )
		{
			if ( aCookies[i].indexOf( sBaseName ) != -1 )
			{
				/* It's a DataTables cookie, so eval it and check the time stamp */
				var aSplitCookie = aCookies[i].split('=');
				try { oData = eval( '('+decodeURIComponent(aSplitCookie[1])+')' ); }
				catch( e ) { continue; }
				
				if ( oData.iCreate && oData.iCreate < iOldTime )
				{
					sOldName = aSplitCookie[0];
					iOldTime = oData.iCreate;
				}
			}
		}
		
		if ( sOldName !== "" )
		{
			document.cookie = sOldName+"=; expires=Thu, 01-Jan-1970 00:00:01 GMT; path="+
				aParts.join('/') + "/";
		}
	}
	
	document.cookie = sFullCookie;
}


/**
 * Read an old cookie to get a cookie with an old table state
 *  @param {string} sName name of the cookie to read
 *  @returns {string} contents of the cookie - or null if no cookie with that name found
 *  @memberof DataTable#oApi
 */
function _fnReadCookie ( sName )
{
	var
		aParts = window.location.pathname.split('/'),
		sNameEQ = sName + '_' + aParts[aParts.length-1].replace(/[\/:]/g,"").toLowerCase() + '=',
	 	sCookieContents = document.cookie.split(';');
	
	for( var i=0 ; i<sCookieContents.length ; i++ )
	{
		var c = sCookieContents[i];
		
		while (c.charAt(0)==' ')
		{
			c = c.substring(1,c.length);
		}
		
		if (c.indexOf(sNameEQ) === 0)
		{
			return decodeURIComponent( c.substring(sNameEQ.length,c.length) );
		}
	}
	return null;
}

