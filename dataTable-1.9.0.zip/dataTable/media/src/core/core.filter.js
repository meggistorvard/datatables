

/**
 * Generate the node required for filtering text
 *  @returns {node} Filter control element
 *  @param {object} oConfigurations dataTables configurations object
 *  @memberof DataTable#oApi
 */
function _fnFeatureHtmlFilter ( oConfigurations )
{
	var oPreviousSearch = oConfigurations.oPreviousSearch;
	
	var sSearchStr = oConfigurations.oLanguage.sSearch;
	sSearchStr = (sSearchStr.indexOf('_INPUT_') !== -1) ?
	  sSearchStr.replace('_INPUT_', '<input type="text" />') :
	  sSearchStr==="" ? '<input type="text" />' : sSearchStr+' <input type="text" />';
	
	var nFilter = document.createElement( 'div' );
	nFilter.className = oConfigurations.oClasses.sFilter;
	nFilter.innerHTML = '<label>'+sSearchStr+'</label>';
	if ( !oConfigurations.aanFeatures.f )
	{
		nFilter.id = oConfigurations.sTableId+'_filter';
	}
	
	var jqFilter = $("input", nFilter);
	jqFilter.val( oPreviousSearch.sSearch.replace('"','&quot;') );
	jqFilter.bind( 'keyup.DT', function(e) {
		/* Update all other filter input elements for the new display */
		var n = oConfigurations.aanFeatures.f;
		for ( var i=0, iLen=n.length ; i<iLen ; i++ )
		{
			if ( n[i] != $(this).parents('div.dataTables_filter')[0] )
			{
				$('input', n[i]).val( this.value );
			}
		}
		
		/* Now do the filter */
		if ( this.value != oPreviousSearch.sSearch )
		{
			_fnFilterComplete( oConfigurations, { 
				"sSearch": this.value, 
				"bRegex": oPreviousSearch.bRegex,
				"bSmart": oPreviousSearch.bSmart ,
				"bCaseInsensitive": oPreviousSearch.bCaseInsensitive 
			} );
		}
	} );

	jqFilter
		.attr('aria-controls', oConfigurations.sTableId)
		.bind( 'keypress.DT', function(e) {
			/* Prevent form submission */
			if ( e.keyCode == 13 )
			{
				return false;
			}
		}
	);
	
	return nFilter;
}


/**
 * Filter the table using both the global filter and column based filtering
 *  @param {object} oConfigurations dataTables configurations object
 *  @param {object} oSearch search information
 *  @param {int} [iForce] force a research of the master array (1) or not (undefined or 0)
 *  @memberof DataTable#oApi
 */
function _fnFilterComplete ( oConfigurations, oInput, iForce )
{
	var oPrevSearch = oConfigurations.oPreviousSearch;
	var aoPrevSearch = oConfigurations.aoPreSearchCols;
	var fnSaveFilter = function ( oFilter ) {
		/* Save the filtering values */
		oPrevSearch.sSearch = oFilter.sSearch;
		oPrevSearch.bRegex = oFilter.bRegex;
		oPrevSearch.bSmart = oFilter.bSmart;
		oPrevSearch.bCaseInsensitive = oFilter.bCaseInsensitive;
	};

	/* In server-side processing all filtering is done by the server, so no point hanging around here */
	if ( !oConfigurations.oFeatures.bServerSide )
	{
		/* Global filter */
		_fnFilter( oConfigurations, oInput.sSearch, iForce, oInput.bRegex, oInput.bSmart, oInput.bCaseInsensitive );
		fnSaveFilter( oInput );

		/* Now do the individual column filter */
		for ( var i=0 ; i<oConfigurations.aoPreSearchCols.length ; i++ )
		{
			_fnFilterColumn( oConfigurations, aoPrevSearch[i].sSearch, i, aoPrevSearch[i].bRegex, 
				aoPrevSearch[i].bSmart, aoPrevSearch[i].bCaseInsensitive );
		}
		
		/* Custom filtering */
		_fnFilterCustom( oConfigurations );
	}
	else
	{
		fnSaveFilter( oInput );
	}
	
	/* Tell the draw function we have been filtering */
	oConfigurations.bFiltered = true;
	$(oConfigurations.oInstance).trigger('filter', oConfigurations);
	
	/* Redraw the table */
	oConfigurations._iDisplayStart = 0;
	_fnCalculateEnd( oConfigurations );
	_fnDraw( oConfigurations );
	
	/* Rebuild search array 'offline' */
	_fnBuildSearchArray( oConfigurations, 0 );
}


/**
 * Apply custom filtering functions
 *  @param {object} oConfigurations dataTables configurations object
 *  @memberof DataTable#oApi
 */
function _fnFilterCustom( oConfigurations )
{
	var afnFilters = DataTable.ext.afnFiltering;
	for ( var i=0, iLen=afnFilters.length ; i<iLen ; i++ )
	{
		var iCorrector = 0;
		for ( var j=0, jLen=oConfigurations.aiDisplay.length ; j<jLen ; j++ )
		{
			var iDisIndex = oConfigurations.aiDisplay[j-iCorrector];
			
			/* Check if we should use this row based on the filtering function */
			if ( !afnFilters[i]( oConfigurations, _fnGetRowData( oConfigurations, iDisIndex, 'filter' ), iDisIndex ) )
			{
				oConfigurations.aiDisplay.splice( j-iCorrector, 1 );
				iCorrector++;
			}
		}
	}
}


/**
 * Filter the table on a per-column basis
 *  @param {object} oConfigurations dataTables configurations object
 *  @param {string} sInput string to filter on
 *  @param {int} iColumn column to filter
 *  @param {bool} bRegex treat search string as a regular expression or not
 *  @param {bool} bSmart use smart filtering or not
 *  @param {bool} bCaseInsensitive Do case insenstive matching or not
 *  @memberof DataTable#oApi
 */
function _fnFilterColumn ( oConfigurations, sInput, iColumn, bRegex, bSmart, bCaseInsensitive )
{
	if ( sInput === "" )
	{
		return;
	}
	
	var iIndexCorrector = 0;
	var rpSearch = _fnFilterCreateSearch( sInput, bRegex, bSmart, bCaseInsensitive );
	
	for ( var i=oConfigurations.aiDisplay.length-1 ; i>=0 ; i-- )
	{
		var sData = _fnDataToSearch( _fnGetCellData( oConfigurations, oConfigurations.aiDisplay[i], iColumn, 'filter' ),
			oConfigurations.aoColumns[iColumn].sType );
		if ( ! rpSearch.test( sData ) )
		{
			oConfigurations.aiDisplay.splice( i, 1 );
			iIndexCorrector++;
		}
	}
}


/**
 * Filter the data table based on member input and draw the table
 *  @param {object} oConfigurations dataTables configurations object
 *  @param {string} sInput string to filter on
 *  @param {int} iForce optional - force a research of the master array (1) or not (undefined or 0)
 *  @param {bool} bRegex treat as a regular expression or not
 *  @param {bool} bSmart perform smart filtering or not
 *  @param {bool} bCaseInsensitive Do case insenstive matching or not
 *  @memberof DataTable#oApi
 */
function _fnFilter( oConfigurations, sInput, iForce, bRegex, bSmart, bCaseInsensitive )
{
	var i;
	var rpSearch = _fnFilterCreateSearch( sInput, bRegex, bSmart, bCaseInsensitive );
	var oPrevSearch = oConfigurations.oPreviousSearch;
	
	/* Check if we are forcing or not - optional parameter */
	if ( !iForce )
	{
		iForce = 0;
	}
	
	/* Need to take account of custom filtering functions - always filter */
	if ( DataTable.ext.afnFiltering.length !== 0 )
	{
		iForce = 1;
	}
	
	/*
	 * If the input is blank - we want the full data set
	 */
	if ( sInput.length <= 0 )
	{
		oConfigurations.aiDisplay.splice( 0, oConfigurations.aiDisplay.length);
		oConfigurations.aiDisplay = oConfigurations.aiDisplayMaster.slice();
	}
	else
	{
		/*
		 * We are starting a new search or the new search string is smaller 
		 * then the old one (i.e. delete). Search from the master array
	 	 */
		if ( oConfigurations.aiDisplay.length == oConfigurations.aiDisplayMaster.length ||
			   oPrevSearch.sSearch.length > sInput.length || iForce == 1 ||
			   sInput.indexOf(oPrevSearch.sSearch) !== 0 )
		{
			/* Nuke the old display array - we are going to rebuild it */
			oConfigurations.aiDisplay.splice( 0, oConfigurations.aiDisplay.length);
			
			/* Force a rebuild of the search array */
			_fnBuildSearchArray( oConfigurations, 1 );
			
			/* Search through all records to populate the search array
			 * The the oConfigurations.aiDisplayMaster and asDataSearch arrays have 1 to 1 
			 * mapping
			 */
			for ( i=0 ; i<oConfigurations.aiDisplayMaster.length ; i++ )
			{
				if ( rpSearch.test(oConfigurations.asDataSearch[i]) )
				{
					oConfigurations.aiDisplay.push( oConfigurations.aiDisplayMaster[i] );
				}
			}
	  }
	  else
		{
	  	/* Using old search array - refine it - do it this way for speed
	  	 * Don't have to search the whole master array again
			 */
	  	var iIndexCorrector = 0;
	  	
	  	/* Search the current results */
	  	for ( i=0 ; i<oConfigurations.asDataSearch.length ; i++ )
			{
	  		if ( ! rpSearch.test(oConfigurations.asDataSearch[i]) )
				{
	  			oConfigurations.aiDisplay.splice( i-iIndexCorrector, 1 );
	  			iIndexCorrector++;
	  		}
	  	}
	  }
	}
}


/**
 * Create an array which can be quickly search through
 *  @param {object} oConfigurations dataTables configurations object
 *  @param {int} iMaster use the master data array - optional
 *  @memberof DataTable#oApi
 */
function _fnBuildSearchArray ( oConfigurations, iMaster )
{
	if ( !oConfigurations.oFeatures.bServerSide )
	{
		/* Clear out the old data */
		oConfigurations.asDataSearch.splice( 0, oConfigurations.asDataSearch.length );
		
		var aArray = (iMaster && iMaster===1) ?
		 	oConfigurations.aiDisplayMaster : oConfigurations.aiDisplay;
		
		for ( var i=0, iLen=aArray.length ; i<iLen ; i++ )
		{
			oConfigurations.asDataSearch[i] = _fnBuildSearchRow( oConfigurations,
				_fnGetRowData( oConfigurations, aArray[i], 'filter' ) );
		}
	}
}


/**
 * Create a searchable string from a single data row
 *  @param {object} oConfigurations dataTables configurations object
 *  @param {array} aData Row data array to use for the data to search
 *  @memberof DataTable#oApi
 */
function _fnBuildSearchRow( oConfigurations, aData )
{
	var sSearch = '';
	if ( oConfigurations.__nTmpFilter === undefined )
	{
		oConfigurations.__nTmpFilter = document.createElement('div');
	}
	var nTmp = oConfigurations.__nTmpFilter;
	
	for ( var j=0, jLen=oConfigurations.aoColumns.length ; j<jLen ; j++ )
	{
		if ( oConfigurations.aoColumns[j].bSearchable )
		{
			var sData = aData[j];
			sSearch += _fnDataToSearch( sData, oConfigurations.aoColumns[j].sType )+'  ';
		}
	}
	
	/* If it looks like there is an HTML entity in the string, attempt to decode it */
	if ( sSearch.indexOf('&') !== -1 )
	{
		nTmp.innerHTML = sSearch;
		sSearch = nTmp.textContent ? nTmp.textContent : nTmp.innerText;
		
		/* IE and Opera appear to put an newline where there is a <br> tag - remove it */
		sSearch = sSearch.replace(/\n/g," ").replace(/\r/g,"");
	}
	
	return sSearch;
}

/**
 * Build a regular expression object suitable for searching a table
 *  @param {string} sSearch string to search for
 *  @param {bool} bRegex treat as a regular expression or not
 *  @param {bool} bSmart perform smart filtering or not
 *  @param {bool} bCaseInsensitive Do case insenstive matching or not
 *  @returns {RegExp} constructed object
 *  @memberof DataTable#oApi
 */
function _fnFilterCreateSearch( sSearch, bRegex, bSmart, bCaseInsensitive )
{
	var asSearch, sRegExpString;
	
	if ( bSmart )
	{
		/* Generate the regular expression to use. Something along the lines of:
		 * ^(?=.*?\bone\b)(?=.*?\btwo\b)(?=.*?\bthree\b).*$
		 */
		asSearch = bRegex ? sSearch.split( ' ' ) : _fnEscapeRegex( sSearch ).split( ' ' );
		sRegExpString = '^(?=.*?'+asSearch.join( ')(?=.*?' )+').*$';
		return new RegExp( sRegExpString, bCaseInsensitive ? "i" : "" );
	}
	else
	{
		sSearch = bRegex ? sSearch : _fnEscapeRegex( sSearch );
		return new RegExp( sSearch, bCaseInsensitive ? "i" : "" );
	}
}


/**
 * Convert raw data into something that the member can search on
 *  @param {string} sData data to be modified
 *  @param {string} sType data type
 *  @returns {string} search string
 *  @memberof DataTable#oApi
 */
function _fnDataToSearch ( sData, sType )
{
	if ( typeof DataTable.ext.ofnSearch[sType] === "function" )
	{
		return DataTable.ext.ofnSearch[sType]( sData );
	}
	else if ( sType == "html" )
	{
		return sData.replace(/[\r\n]/g," ").replace( /<.*?>/g, "" );
	}
	else if ( typeof sData === "string" )
	{
		return sData.replace(/[\r\n]/g," ");
	}
	else if ( sData === null )
	{
		return '';
	}
	return sData;
}


/**
 * scape a string stuch that it can be used in a regular expression
 *  @param {string} sVal string to escape
 *  @returns {string} escaped string
 *  @memberof DataTable#oApi
 */
function _fnEscapeRegex ( sVal )
{
	var acEscape = [ '/', '.', '*', '+', '?', '|', '(', ')', '[', ']', '{', '}', '\\', '$', '^' ];
	var reReplace = new RegExp( '(\\' + acEscape.join('|\\') + ')', 'g' );
	return sVal.replace(reReplace, '\\$1');
}

