

/**
 * Generate the node required for member display length changing
 *  @param {object} oConfigurations dataTables configurations object
 *  @returns {node} Display length feature node
 *  @memberof DataTable#oApi
 */
function _fnFeatureHtmlLength ( oConfigurations )
{
	if ( oConfigurations.oScroll.bInfinite )
	{
		return null;
	}
	
	/* This can be overruled by not using the _MENU_ var/macro in the language variable */
	var sName = 'name="'+oConfigurations.sTableId+'_length"';
	var sStdMenu = '<select size="1" '+sName+'>';
	var i, iLen;
	var aLengthMenu = oConfigurations.aLengthMenu;
	
	if ( aLengthMenu.length == 2 && typeof aLengthMenu[0] === 'object' && 
			typeof aLengthMenu[1] === 'object' )
	{
		for ( i=0, iLen=aLengthMenu[0].length ; i<iLen ; i++ )
		{
			sStdMenu += '<option value="'+aLengthMenu[0][i]+'">'+aLengthMenu[1][i]+'</option>';
		}
	}
	else
	{
		for ( i=0, iLen=aLengthMenu.length ; i<iLen ; i++ )
		{
			sStdMenu += '<option value="'+aLengthMenu[i]+'">'+aLengthMenu[i]+'</option>';
		}
	}
	sStdMenu += '</select>';
	
	var nLength = document.createElement( 'div' );
	if ( !oConfigurations.aanFeatures.l )
	{
		nLength.id = oConfigurations.sTableId+'_length';
	}
	nLength.className = oConfigurations.oClasses.sLength;
	nLength.innerHTML = '<label>'+oConfigurations.oLanguage.sLengthMenu.replace( '_MENU_', sStdMenu )+'</label>';
	
	/*
	 * Set the length to the current display length - thanks to Andrea Pavlovic for this fix,
	 * and Stefan Skopnik for fixing the fix!
	 */
	$('select option[value="'+oConfigurations._iDisplayLength+'"]', nLength).attr("selected", true);
	
	$('select', nLength).bind( 'change.DT', function(e) {
		var iVal = $(this).val();
		
		/* Update all other length options for the new display */
		var n = oConfigurations.aanFeatures.l;
		for ( i=0, iLen=n.length ; i<iLen ; i++ )
		{
			if ( n[i] != this.parentNode )
			{
				$('select', n[i]).val( iVal );
			}
		}
		
		/* Redraw the table */
		oConfigurations._iDisplayLength = parseInt(iVal, 10);
		_fnCalculateEnd( oConfigurations );
		
		/* If we have space to show extra rows (backing up from the end point - then do so */
		if ( oConfigurations.fnDisplayEnd() == oConfigurations.fnRecordsDisplay() )
		{
			oConfigurations._iDisplayStart = oConfigurations.fnDisplayEnd() - oConfigurations._iDisplayLength;
			if ( oConfigurations._iDisplayStart < 0 )
			{
				oConfigurations._iDisplayStart = 0;
			}
		}
		
		if ( oConfigurations._iDisplayLength == -1 )
		{
			oConfigurations._iDisplayStart = 0;
		}
		
		_fnDraw( oConfigurations );
	} );


	$('select', nLength).attr('aria-controls', oConfigurations.sTableId);
	
	return nLength;
}


/**
 * Rcalculate the end point based on the start point
 *  @param {object} oConfigurations dataTables configurations object
 *  @memberof DataTable#oApi
 */
function _fnCalculateEnd( oConfigurations )
{
	if ( oConfigurations.oFeatures.bPaginate === false )
	{
		oConfigurations._iDisplayEnd = oConfigurations.aiDisplay.length;
	}
	else
	{
		/* Set the end point of the display - based on how many elements there are
		 * still to display
		 */
		if ( oConfigurations._iDisplayStart + oConfigurations._iDisplayLength > oConfigurations.aiDisplay.length ||
			   oConfigurations._iDisplayLength == -1 )
		{
			oConfigurations._iDisplayEnd = oConfigurations.aiDisplay.length;
		}
		else
		{
			oConfigurations._iDisplayEnd = oConfigurations._iDisplayStart + oConfigurations._iDisplayLength;
		}
	}
}

